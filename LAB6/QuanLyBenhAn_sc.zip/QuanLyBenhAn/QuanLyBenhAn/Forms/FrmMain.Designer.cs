﻿namespace QuanLyBenhAn.Forms
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnXetNghiem = new System.Windows.Forms.Button();
            this.btnLuuTru = new System.Windows.Forms.Button();
            this.btnKhamBenh = new System.Windows.Forms.Button();
            this.btnHoSo = new System.Windows.Forms.Button();
            this.btnDanhMuc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(482, 513);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(399, 102);
            this.btnThoat.TabIndex = 13;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            // 
            // btnXetNghiem
            // 
            this.btnXetNghiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXetNghiem.Location = new System.Drawing.Point(42, 362);
            this.btnXetNghiem.Name = "btnXetNghiem";
            this.btnXetNghiem.Size = new System.Drawing.Size(399, 102);
            this.btnXetNghiem.TabIndex = 12;
            this.btnXetNghiem.Text = "Xét nghiệm - Đơn thuốc";
            this.btnXetNghiem.UseVisualStyleBackColor = true;
            // 
            // btnLuuTru
            // 
            this.btnLuuTru.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuTru.Location = new System.Drawing.Point(482, 362);
            this.btnLuuTru.Name = "btnLuuTru";
            this.btnLuuTru.Size = new System.Drawing.Size(399, 102);
            this.btnLuuTru.TabIndex = 11;
            this.btnLuuTru.Text = "Thanh toán - Lưu trữ";
            this.btnLuuTru.UseVisualStyleBackColor = true;
            // 
            // btnKhamBenh
            // 
            this.btnKhamBenh.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhamBenh.Location = new System.Drawing.Point(924, 218);
            this.btnKhamBenh.Name = "btnKhamBenh";
            this.btnKhamBenh.Size = new System.Drawing.Size(399, 102);
            this.btnKhamBenh.TabIndex = 10;
            this.btnKhamBenh.Text = "Đặt lịch - Khám bệnh";
            this.btnKhamBenh.UseVisualStyleBackColor = true;
            // 
            // btnHoSo
            // 
            this.btnHoSo.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoSo.Location = new System.Drawing.Point(482, 218);
            this.btnHoSo.Name = "btnHoSo";
            this.btnHoSo.Size = new System.Drawing.Size(399, 102);
            this.btnHoSo.TabIndex = 9;
            this.btnHoSo.Text = "Bệnh nhân - Hồ sơ";
            this.btnHoSo.UseVisualStyleBackColor = true;
            // 
            // btnDanhMuc
            // 
            this.btnDanhMuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDanhMuc.Location = new System.Drawing.Point(42, 218);
            this.btnDanhMuc.Name = "btnDanhMuc";
            this.btnDanhMuc.Size = new System.Drawing.Size(399, 102);
            this.btnDanhMuc.TabIndex = 8;
            this.btnDanhMuc.Text = "Danh mục";
            this.btnDanhMuc.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(184, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1014, 69);
            this.label1.TabIndex = 7;
            this.label1.Text = "QUẢN LÝ HỒ SƠ BỆNH ÁN";
            // 
            // btnThongKe
            // 
            this.btnThongKe.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongKe.Location = new System.Drawing.Point(924, 362);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(399, 102);
            this.btnThongKe.TabIndex = 14;
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.UseVisualStyleBackColor = true;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 797);
            this.Controls.Add(this.btnThongKe);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnXetNghiem);
            this.Controls.Add(this.btnLuuTru);
            this.Controls.Add(this.btnKhamBenh);
            this.Controls.Add(this.btnHoSo);
            this.Controls.Add(this.btnDanhMuc);
            this.Controls.Add(this.label1);
            this.Name = "FrmMain";
            this.Text = "QUẢN LÝ HỒ SƠ BỆNH ÁN";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnXetNghiem;
        private System.Windows.Forms.Button btnLuuTru;
        private System.Windows.Forms.Button btnKhamBenh;
        private System.Windows.Forms.Button btnHoSo;
        private System.Windows.Forms.Button btnDanhMuc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThongKe;
    }
}