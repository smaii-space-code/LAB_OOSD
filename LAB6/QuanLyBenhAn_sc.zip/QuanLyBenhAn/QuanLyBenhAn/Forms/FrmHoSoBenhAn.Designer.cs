﻿namespace QuanLyBenhAn.Forms
{
    partial class FrmHoSoBenhAn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabBenhNhan = new System.Windows.Forms.TabPage();
            this.cboLoai = new System.Windows.Forms.ComboBox();
            this.numSTT = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dgvBenhNhan = new System.Windows.Forms.DataGridView();
            this.btnThemBenhNhan = new System.Windows.Forms.Button();
            this.txtTinhTrang = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMaBenhNhan = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.TabThuPhi = new System.Windows.Forms.TabPage();
            this.dgvThuPhi = new System.Windows.Forms.DataGridView();
            this.MaPhieuThu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaBenhNhan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GioiTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoSo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.cboNV = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSoTienThu = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dtNgay = new System.Windows.Forms.DateTimePicker();
            this.cboHoSo = new System.Windows.Forms.ComboBox();
            this.cboBenhNhan = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btnThuPhi = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.txtMaThu = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.TabHoSo = new System.Windows.Forms.TabPage();
            this.numMax = new System.Windows.Forms.NumericUpDown();
            this.cboChonBenhNhan = new System.Windows.Forms.ComboBox();
            this.numGia = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvHoSo = new System.Windows.Forms.DataGridView();
            this.MaHoSo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoTenBenhNhan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NamLap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhiNam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TrangThai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnThemHoSo = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtHoSo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.MaTN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Loai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.STT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabBenhNhan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSTT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBenhNhan)).BeginInit();
            this.TabThuPhi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThuPhi)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.TabHoSo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoSo)).BeginInit();
            this.SuspendLayout();
            // 
            // TabBenhNhan
            // 
            this.TabBenhNhan.Controls.Add(this.cboLoai);
            this.TabBenhNhan.Controls.Add(this.numSTT);
            this.TabBenhNhan.Controls.Add(this.label9);
            this.TabBenhNhan.Controls.Add(this.label10);
            this.TabBenhNhan.Controls.Add(this.dgvBenhNhan);
            this.TabBenhNhan.Controls.Add(this.btnThemBenhNhan);
            this.TabBenhNhan.Controls.Add(this.txtTinhTrang);
            this.TabBenhNhan.Controls.Add(this.label11);
            this.TabBenhNhan.Controls.Add(this.txtMaBenhNhan);
            this.TabBenhNhan.Controls.Add(this.label12);
            this.TabBenhNhan.Location = new System.Drawing.Point(4, 38);
            this.TabBenhNhan.Name = "TabBenhNhan";
            this.TabBenhNhan.Padding = new System.Windows.Forms.Padding(3);
            this.TabBenhNhan.Size = new System.Drawing.Size(1358, 787);
            this.TabBenhNhan.TabIndex = 3;
            this.TabBenhNhan.Text = "Bệnh nhân";
            this.TabBenhNhan.UseVisualStyleBackColor = true;
            // 
            // cboLoai
            // 
            this.cboLoai.FormattingEnabled = true;
            this.cboLoai.Location = new System.Drawing.Point(316, 96);
            this.cboLoai.Name = "cboLoai";
            this.cboLoai.Size = new System.Drawing.Size(181, 37);
            this.cboLoai.TabIndex = 33;
            // 
            // numSTT
            // 
            this.numSTT.Location = new System.Drawing.Point(720, 94);
            this.numSTT.Name = "numSTT";
            this.numSTT.Size = new System.Drawing.Size(182, 34);
            this.numSTT.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(547, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 29);
            this.label9.TabIndex = 18;
            this.label9.Text = "Năm sinh:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(150, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 29);
            this.label10.TabIndex = 16;
            this.label10.Text = "Giới tính:";
            // 
            // dgvBenhNhan
            // 
            this.dgvBenhNhan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBenhNhan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaTN,
            this.Loai,
            this.STT,
            this.TinhTrang});
            this.dgvBenhNhan.Location = new System.Drawing.Point(155, 179);
            this.dgvBenhNhan.Name = "dgvBenhNhan";
            this.dgvBenhNhan.RowHeadersWidth = 51;
            this.dgvBenhNhan.RowTemplate.Height = 24;
            this.dgvBenhNhan.Size = new System.Drawing.Size(1054, 564);
            this.dgvBenhNhan.TabIndex = 15;
            // 
            // btnThemBenhNhan
            // 
            this.btnThemBenhNhan.Location = new System.Drawing.Point(1003, 46);
            this.btnThemBenhNhan.Name = "btnThemBenhNhan";
            this.btnThemBenhNhan.Size = new System.Drawing.Size(183, 36);
            this.btnThemBenhNhan.TabIndex = 14;
            this.btnThemBenhNhan.Text = "Thêm";
            this.btnThemBenhNhan.UseVisualStyleBackColor = true;
            // 
            // txtTinhTrang
            // 
            this.txtTinhTrang.Location = new System.Drawing.Point(720, 45);
            this.txtTinhTrang.Name = "txtTinhTrang";
            this.txtTinhTrang.Size = new System.Drawing.Size(182, 34);
            this.txtTinhTrang.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(547, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(127, 29);
            this.label11.TabIndex = 12;
            this.label11.Text = "Họ tên:";
            // 
            // txtMaBenhNhan
            // 
            this.txtMaBenhNhan.Location = new System.Drawing.Point(316, 43);
            this.txtMaBenhNhan.Name = "txtMaBenhNhan";
            this.txtMaBenhNhan.Size = new System.Drawing.Size(182, 34);
            this.txtMaBenhNhan.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(150, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(149, 29);
            this.label12.TabIndex = 10;
            this.label12.Text = "Mã bệnh nhân:";
            // 
            // TabThuPhi
            // 
            this.TabThuPhi.Controls.Add(this.dgvThuPhi);
            this.TabThuPhi.Controls.Add(this.txtGhiChu);
            this.TabThuPhi.Controls.Add(this.cboNV);
            this.TabThuPhi.Controls.Add(this.label6);
            this.TabThuPhi.Controls.Add(this.label7);
            this.TabThuPhi.Controls.Add(this.txtSoTienThu);
            this.TabThuPhi.Controls.Add(this.label8);
            this.TabThuPhi.Controls.Add(this.dtNgay);
            this.TabThuPhi.Controls.Add(this.cboHoSo);
            this.TabThuPhi.Controls.Add(this.cboBenhNhan);
            this.TabThuPhi.Controls.Add(this.label13);
            this.TabThuPhi.Controls.Add(this.label14);
            this.TabThuPhi.Controls.Add(this.btnThuPhi);
            this.TabThuPhi.Controls.Add(this.label15);
            this.TabThuPhi.Controls.Add(this.txtMaThu);
            this.TabThuPhi.Controls.Add(this.label16);
            this.TabThuPhi.Location = new System.Drawing.Point(4, 38);
            this.TabThuPhi.Name = "TabThuPhi";
            this.TabThuPhi.Padding = new System.Windows.Forms.Padding(3);
            this.TabThuPhi.Size = new System.Drawing.Size(1358, 787);
            this.TabThuPhi.TabIndex = 4;
            this.TabThuPhi.Text = "Thu phí năm";
            this.TabThuPhi.UseVisualStyleBackColor = true;
            // 
            // dgvThuPhi
            // 
            this.dgvThuPhi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThuPhi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaPhieuThu,
            this.MaBenhNhan,
            this.GioiTinh,
            this.HoSo,
            this.NgayLap,
            this.TT,
            this.MaNV,
            this.GhiChu});
            this.dgvThuPhi.Location = new System.Drawing.Point(39, 196);
            this.dgvThuPhi.Name = "dgvThuPhi";
            this.dgvThuPhi.RowHeadersWidth = 51;
            this.dgvThuPhi.RowTemplate.Height = 24;
            this.dgvThuPhi.Size = new System.Drawing.Size(1055, 229);
            this.dgvThuPhi.TabIndex = 42;
            // 
            // MaPhieuThu
            // 
            this.MaPhieuThu.DataPropertyName = "MaPhieuThu";
            this.MaPhieuThu.HeaderText = "Mã thu";
            this.MaPhieuThu.MinimumWidth = 6;
            this.MaPhieuThu.Name = "MaPhieuThu";
            this.MaPhieuThu.Width = 125;
            // 
            // MaBenhNhan
            // 
            this.MaBenhNhan.DataPropertyName = "MaBenhNhan";
            this.MaBenhNhan.HeaderText = "Mã bệnh nhân";
            this.MaBenhNhan.MinimumWidth = 6;
            this.MaBenhNhan.Name = "MaBenhNhan";
            this.MaBenhNhan.Width = 125;
            // 
            // GioiTinh
            // 
            this.GioiTinh.DataPropertyName = "GioiTinh";
            this.GioiTinh.HeaderText = "Giới tính";
            this.GioiTinh.MinimumWidth = 6;
            this.GioiTinh.Name = "GioiTinh";
            this.GioiTinh.Width = 125;
            // 
            // HoSo
            // 
            this.HoSo.DataPropertyName = "MaHoSo";
            this.HoSo.HeaderText = "Mã hồ sơ";
            this.HoSo.MinimumWidth = 6;
            this.HoSo.Name = "HoSo";
            this.HoSo.Width = 125;
            // 
            // NgayLap
            // 
            this.NgayLap.DataPropertyName = "NgayLap";
            this.NgayLap.HeaderText = "Ngày thu";
            this.NgayLap.MinimumWidth = 6;
            this.NgayLap.Name = "NgayLap";
            this.NgayLap.Width = 125;
            // 
            // TT
            // 
            this.TT.DataPropertyName = "TinhTrang";
            this.TT.HeaderText = "Trạng thái";
            this.TT.MinimumWidth = 6;
            this.TT.Name = "TT";
            this.TT.Width = 125;
            // 
            // MaNV
            // 
            this.MaNV.DataPropertyName = "MaNV";
            this.MaNV.HeaderText = "Mã nhân viên";
            this.MaNV.MinimumWidth = 6;
            this.MaNV.Name = "MaNV";
            this.MaNV.Width = 125;
            // 
            // GhiChu
            // 
            this.GhiChu.DataPropertyName = "GhiChu";
            this.GhiChu.HeaderText = "Ghi chú";
            this.GhiChu.MinimumWidth = 6;
            this.GhiChu.Name = "GhiChu";
            this.GhiChu.Width = 125;
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Location = new System.Drawing.Point(936, 23);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(200, 34);
            this.txtGhiChu.TabIndex = 41;
            // 
            // cboNV
            // 
            this.cboNV.FormattingEnabled = true;
            this.cboNV.Location = new System.Drawing.Point(936, 79);
            this.cboNV.Name = "cboNV";
            this.cboNV.Size = new System.Drawing.Size(200, 37);
            this.cboNV.TabIndex = 40;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(758, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 29);
            this.label6.TabIndex = 37;
            this.label6.Text = "Ghi chú:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(758, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 29);
            this.label7.TabIndex = 36;
            this.label7.Text = "Nhân viên:";
            // 
            // txtSoTienThu
            // 
            this.txtSoTienThu.Location = new System.Drawing.Point(251, 136);
            this.txtSoTienThu.Name = "txtSoTienThu";
            this.txtSoTienThu.Size = new System.Drawing.Size(337, 34);
            this.txtSoTienThu.TabIndex = 35;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 139);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(198, 29);
            this.label8.TabIndex = 34;
            this.label8.Text = "Số tiền thu:";
            // 
            // dtNgay
            // 
            this.dtNgay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgay.Location = new System.Drawing.Point(530, 77);
            this.dtNgay.Name = "dtNgay";
            this.dtNgay.Size = new System.Drawing.Size(200, 34);
            this.dtNgay.TabIndex = 33;
            // 
            // cboHoSo
            // 
            this.cboHoSo.FormattingEnabled = true;
            this.cboHoSo.Location = new System.Drawing.Point(530, 26);
            this.cboHoSo.Name = "cboHoSo";
            this.cboHoSo.Size = new System.Drawing.Size(200, 37);
            this.cboHoSo.TabIndex = 32;
            // 
            // cboBenhNhan
            // 
            this.cboBenhNhan.FormattingEnabled = true;
            this.cboBenhNhan.Location = new System.Drawing.Point(201, 74);
            this.cboBenhNhan.Name = "cboBenhNhan";
            this.cboBenhNhan.Size = new System.Drawing.Size(181, 37);
            this.cboBenhNhan.TabIndex = 31;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(410, 79);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 29);
            this.label13.TabIndex = 29;
            this.label13.Text = "Ngày:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(34, 74);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(120, 29);
            this.label14.TabIndex = 27;
            this.label14.Text = "Bệnh nhân:";
            // 
            // btnThuPhi
            // 
            this.btnThuPhi.Location = new System.Drawing.Point(763, 134);
            this.btnThuPhi.Name = "btnThuPhi";
            this.btnThuPhi.Size = new System.Drawing.Size(183, 36);
            this.btnThuPhi.TabIndex = 25;
            this.btnThuPhi.Text = "Thêm";
            this.btnThuPhi.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(410, 33);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 29);
            this.label15.TabIndex = 23;
            this.label15.Text = "Hồ sơ:";
            // 
            // txtMaThu
            // 
            this.txtMaThu.Location = new System.Drawing.Point(200, 26);
            this.txtMaThu.Name = "txtMaThu";
            this.txtMaThu.Size = new System.Drawing.Size(182, 34);
            this.txtMaThu.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(34, 28);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(127, 29);
            this.label16.TabIndex = 21;
            this.label16.Text = "Số phiếu thu:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.TabHoSo);
            this.tabControl1.Controls.Add(this.TabBenhNhan);
            this.tabControl1.Controls.Add(this.TabThuPhi);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(-1, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1366, 829);
            this.tabControl1.TabIndex = 1;
            // 
            // TabHoSo
            // 
            this.TabHoSo.Controls.Add(this.numMax);
            this.TabHoSo.Controls.Add(this.cboChonBenhNhan);
            this.TabHoSo.Controls.Add(this.numGia);
            this.TabHoSo.Controls.Add(this.label1);
            this.TabHoSo.Controls.Add(this.label2);
            this.TabHoSo.Controls.Add(this.dgvHoSo);
            this.TabHoSo.Controls.Add(this.btnThemHoSo);
            this.TabHoSo.Controls.Add(this.label3);
            this.TabHoSo.Controls.Add(this.txtHoSo);
            this.TabHoSo.Controls.Add(this.label4);
            this.TabHoSo.Location = new System.Drawing.Point(4, 38);
            this.TabHoSo.Name = "TabHoSo";
            this.TabHoSo.Padding = new System.Windows.Forms.Padding(3);
            this.TabHoSo.Size = new System.Drawing.Size(1358, 787);
            this.TabHoSo.TabIndex = 2;
            this.TabHoSo.Text = "Hồ sơ bệnh án";
            this.TabHoSo.UseVisualStyleBackColor = true;
            // 
            // numMax
            // 
            this.numMax.Location = new System.Drawing.Point(720, 45);
            this.numMax.Name = "numMax";
            this.numMax.Size = new System.Drawing.Size(182, 34);
            this.numMax.TabIndex = 33;
            // 
            // cboChonBenhNhan
            // 
            this.cboChonBenhNhan.FormattingEnabled = true;
            this.cboChonBenhNhan.Location = new System.Drawing.Point(316, 91);
            this.cboChonBenhNhan.Name = "cboChonBenhNhan";
            this.cboChonBenhNhan.Size = new System.Drawing.Size(181, 37);
            this.cboChonBenhNhan.TabIndex = 32;
            // 
            // numGia
            // 
            this.numGia.Location = new System.Drawing.Point(720, 94);
            this.numGia.Name = "numGia";
            this.numGia.Size = new System.Drawing.Size(182, 34);
            this.numGia.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(547, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 29);
            this.label1.TabIndex = 29;
            this.label1.Text = "Phí năm:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(150, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 29);
            this.label2.TabIndex = 27;
            this.label2.Text = "Bệnh nhân:";
            // 
            // dgvHoSo
            // 
            this.dgvHoSo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoSo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHoSo,
            this.HoTenBenhNhan,
            this.NamLap,
            this.PhiNam,
            this.TrangThai});
            this.dgvHoSo.Location = new System.Drawing.Point(155, 179);
            this.dgvHoSo.Name = "dgvHoSo";
            this.dgvHoSo.RowHeadersWidth = 51;
            this.dgvHoSo.RowTemplate.Height = 24;
            this.dgvHoSo.Size = new System.Drawing.Size(1054, 564);
            this.dgvHoSo.TabIndex = 26;
            // 
            // MaHoSo
            // 
            this.MaHoSo.DataPropertyName = "MaHoSo";
            this.MaHoSo.HeaderText = "Hồ sơ";
            this.MaHoSo.MinimumWidth = 6;
            this.MaHoSo.Name = "MaHoSo";
            this.MaHoSo.Width = 250;
            // 
            // HoTenBenhNhan
            // 
            this.HoTenBenhNhan.DataPropertyName = "HoTenBenhNhan";
            this.HoTenBenhNhan.HeaderText = "Khu";
            this.HoTenBenhNhan.MinimumWidth = 6;
            this.HoTenBenhNhan.Name = "HoTenBenhNhan";
            this.HoTenBenhNhan.Width = 250;
            // 
            // NamLap
            // 
            this.NamLap.DataPropertyName = "NamLap";
            this.NamLap.HeaderText = "Max";
            this.NamLap.MinimumWidth = 6;
            this.NamLap.Name = "NamLap";
            this.NamLap.Width = 250;
            // 
            // PhiNam
            // 
            this.PhiNam.DataPropertyName = "PhiNam";
            this.PhiNam.HeaderText = "Giá";
            this.PhiNam.MinimumWidth = 6;
            this.PhiNam.Name = "PhiNam";
            this.PhiNam.Width = 250;
            // 
            // TrangThai
            // 
            this.TrangThai.DataPropertyName = "TrangThai";
            this.TrangThai.HeaderText = "TrangThai";
            this.TrangThai.MinimumWidth = 6;
            this.TrangThai.Name = "TrangThai";
            this.TrangThai.Width = 125;
            // 
            // btnThemHoSo
            // 
            this.btnThemHoSo.Location = new System.Drawing.Point(1003, 46);
            this.btnThemHoSo.Name = "btnThemHoSo";
            this.btnThemHoSo.Size = new System.Drawing.Size(183, 36);
            this.btnThemHoSo.TabIndex = 25;
            this.btnThemHoSo.Text = "Thêm";
            this.btnThemHoSo.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(547, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 29);
            this.label3.TabIndex = 23;
            this.label3.Text = "Năm lập:";
            // 
            // txtHoSo
            // 
            this.txtHoSo.Location = new System.Drawing.Point(316, 43);
            this.txtHoSo.Name = "txtHoSo";
            this.txtHoSo.Size = new System.Drawing.Size(182, 34);
            this.txtHoSo.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(150, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 29);
            this.label4.TabIndex = 21;
            this.label4.Text = "Mã hồ sơ:";
            // 
            // MaTN
            // 
            this.MaTN.DataPropertyName = "MaBenhNhan";
            this.MaTN.HeaderText = "Mã bệnh nhân";
            this.MaTN.MinimumWidth = 6;
            this.MaTN.Name = "MaTN";
            this.MaTN.Width = 250;
            // 
            // Loai
            // 
            this.Loai.DataPropertyName = "GioiTinh";
            this.Loai.HeaderText = "Loại";
            this.Loai.MinimumWidth = 6;
            this.Loai.Name = "Loai";
            this.Loai.Width = 250;
            // 
            // STT
            // 
            this.STT.DataPropertyName = "SoThuTu";
            this.STT.HeaderText = "Năm sinh";
            this.STT.MinimumWidth = 6;
            this.STT.Name = "STT";
            this.STT.Width = 250;
            // 
            // TinhTrang
            // 
            this.TinhTrang.DataPropertyName = "HoTenBenhNhan";
            this.TinhTrang.HeaderText = "Tình trạng";
            this.TinhTrang.MinimumWidth = 6;
            this.TinhTrang.Name = "TinhTrang";
            this.TinhTrang.Width = 250;
            // 
            // Frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1364, 842);
            this.Controls.Add(this.tabControl1);
            this.Name = "Frm";
            this.Text = "Bệnh nhân - Hồ sơ bệnh án - Phí năm";
            this.TabBenhNhan.ResumeLayout(false);
            this.TabBenhNhan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSTT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBenhNhan)).EndInit();
            this.TabThuPhi.ResumeLayout(false);
            this.TabThuPhi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThuPhi)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.TabHoSo.ResumeLayout(false);
            this.TabHoSo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoSo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage TabBenhNhan;
        private System.Windows.Forms.NumericUpDown numSTT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dgvBenhNhan;
        private System.Windows.Forms.Button btnThemBenhNhan;
        private System.Windows.Forms.TextBox txtTinhTrang;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtMaBenhNhan;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage TabThuPhi;
        private System.Windows.Forms.ComboBox cboBenhNhan;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnThuPhi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtMaThu;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage TabHoSo;
        private System.Windows.Forms.NumericUpDown numGia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvHoSo;
        private System.Windows.Forms.Button btnThemHoSo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtHoSo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numMax;
        private System.Windows.Forms.ComboBox cboChonBenhNhan;
        private System.Windows.Forms.ComboBox cboLoai;
        private System.Windows.Forms.DateTimePicker dtNgay;
        private System.Windows.Forms.ComboBox cboHoSo;
        private System.Windows.Forms.ComboBox cboNV;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSoTienThu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHoSo;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoTenBenhNhan;
        private System.Windows.Forms.DataGridViewTextBoxColumn NamLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhiNam;
        private System.Windows.Forms.DataGridViewTextBoxColumn TrangThai;
        private System.Windows.Forms.DataGridView dgvThuPhi;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaPhieuThu;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaBenhNhan;
        private System.Windows.Forms.DataGridViewTextBoxColumn GioiTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoSo;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayLap;
        private System.Windows.Forms.DataGridViewTextBoxColumn TT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn GhiChu;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTN;
        private System.Windows.Forms.DataGridViewTextBoxColumn Loai;
        private System.Windows.Forms.DataGridViewTextBoxColumn STT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TinhTrang;
    }
}