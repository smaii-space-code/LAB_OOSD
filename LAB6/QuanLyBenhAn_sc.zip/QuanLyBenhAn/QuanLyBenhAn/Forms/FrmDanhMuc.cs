﻿using System; using System.Windows.Forms; using QuanLyBenhAn.Data; using QuanLyBenhAn.Services;
namespace QuanLyBenhAn.Forms { public partial class FrmDanhMuc:Form {
 public FrmDanhMuc() { InitializeComponent(); DanhMucService.Setup(this,"Danh mục dùng chung"); DanhMucService.Number(numDVGia,1000000000,50000);DanhMucService.Number(numQDTien,1000000000,200000);cboQDLoai.Items.Clear();cboQDLoai.Items.AddRange(new object[]{"Thông thường","Ưu tiên"});cboQDLoai.SelectedIndex=0;
 btnThemKhoa.Click+=(s,e)=>DanhMucService.Try(()=>Save("Khoa",DanhMucService.Text(txtKhoaMa),DanhMucService.Text(txtKhoaTen)));
 btnThemNV.Click+=(s,e)=>DanhMucService.Try(()=>Save("NhanVien",DanhMucService.Text(txtNVMa),DanhMucService.Text(txtNVTen),DanhMucService.Text(txtNVVaiTro),txtNVSDT.Text.Trim()));
 btnThemLoaiHoSo.Click+=(s,e)=>DanhMucService.Try(()=>Save("LoaiHoSo",DanhMucService.Text(txtLoaiMa),DanhMucService.Text(txtLoaiTen)));
 btnThemDV.Click+=(s,e)=>DanhMucService.Try(()=>Save("DichVu",DanhMucService.Text(txtDVMa),DanhMucService.Text(txtDVTen),DanhMucService.Text(txtDVDVT),numDVGia.Value));
 btnThemQD.Click+=(s,e)=>DanhMucService.Try(()=>Save("MucPhi",DanhMucService.Text(txtQDMa),cboQDLoai.Text,DanhMucService.Text(txtQDMucDo),numQDTien.Value));
 RefreshTables(); }
 void Save(string table,params object[] values) { DanhMucService.Run(()=>HoSoBenhAnService.Add(table,values),RefreshTables); }
 void RefreshTables() { DanhMucService.Grid(dgvKhoa,Db.Table("Khoa"));DanhMucService.Grid(dgvNV,Db.Table("NhanVien"));DanhMucService.Grid(dgvLoaiHoSo,Db.Table("LoaiHoSo"));DanhMucService.Grid(dgvDV,Db.Table("DichVu"));DanhMucService.Grid(dgvQD,Db.Table("MucPhi")); }
} }