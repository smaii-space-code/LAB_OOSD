﻿using System; using System.Windows.Forms; using QuanLyBenhAn.Services;
namespace QuanLyBenhAn.Forms { public partial class FrmMain:Form {
 public FrmMain() { InitializeComponent(); DanhMucService.Setup(this,"Quản lý hồ sơ bệnh án — Mai Phước Sang");
 btnDanhMuc.Click+=(s,e)=>ShowForm(new FrmDanhMuc()); btnHoSo.Click+=(s,e)=>ShowForm(new FrmHoSoBenhAn()); btnKhamBenh.Click+=(s,e)=>ShowForm(new FrmKhamBenh()); btnXetNghiem.Click+=(s,e)=>ShowForm(new FrmXetNghiem()); btnLuuTru.Click+=(s,e)=>ShowForm(new FrmThanhToan()); btnThongKe.Click+=(s,e)=>ShowForm(new FrmThongKe()); btnThoat.Click+=(s,e)=>Close();
 FormClosing+=(s,e)=>{if(MessageBox.Show("Bạn có muốn thoát?","Xác nhận",MessageBoxButtons.YesNo)==DialogResult.No)e.Cancel=true;}; }
 void ShowForm(Form f) { using(f) f.ShowDialog(this); }
} }