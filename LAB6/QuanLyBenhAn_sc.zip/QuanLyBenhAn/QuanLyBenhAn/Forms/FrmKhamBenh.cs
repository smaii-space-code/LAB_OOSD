﻿using System; using System.Data; using System.Drawing; using System.Linq; using System.Windows.Forms; using QuanLyBenhAn.Data; using QuanLyBenhAn.Services;
namespace QuanLyBenhAn.Forms { public partial class FrmKhamBenh:Form {
 ComboBox hs=new ComboBox(),bs=new ComboBox(),loai=new ComboBox();DateTimePicker ngay=new DateTimePicker();DataGridView lich=new DataGridView(),kham=new DataGridView(),luu=new DataGridView(); TextBox trieu=new TextBox(),chan=new TextBox(),tim=new TextBox();
 public FrmKhamBenh() { InitializeComponent();DanhMucService.Setup(this,"Đặt lịch - Tiếp nhận - Khám bệnh");
 Field(tabHen,"Hồ sơ",hs,25,25);Field(tabHen,"Bác sĩ",bs,430,25);Field(tabHen,"Ngày giờ khám",ngay,25,80);Field(tabHen,"Loại khám",loai,430,80);ngay.Format=DateTimePickerFormat.Custom;ngay.CustomFormat="dd/MM/yyyy HH:mm";loai.DropDownStyle=ComboBoxStyle.DropDownList;loai.Items.AddRange(new object[]{"Thông thường","Định kỳ"});loai.SelectedIndex=0;
 DanhMucService.VisibleButton(tabHen,"Đặt lịch",25,135,150,()=>DanhMucService.Run(()=>{var date=ngay.Value;string doctor=DanhMucService.Selected(bs);HoSoBenhAnService.Require(date>=DateTime.Now.AddMinutes(-1),"Lịch hẹn phải từ hiện tại trở đi.");HoSoBenhAnService.Require(!Db.Table("LichHen").AsEnumerable().Any(r=>r.Field<string>("MaBS")==doctor&&r.Field<string>("TrangThai")=="Chờ khám"&&Math.Abs((r.Field<DateTime>("NgayHen")-date).TotalMinutes)<30),"Bác sĩ đã có lịch trong khoảng 30 phút này.");HoSoBenhAnService.Add("LichHen",HoSoBenhAnService.Id("LH"),DanhMucService.Selected(hs),doctor,date,loai.Text,"Chờ khám");},RefreshAll));
 DanhMucService.VisibleButton(tabHen,"Tiếp nhận lịch chọn",190,135,200,()=>DanhMucService.Run(()=>{var r=DanhMucService.Selected(lich);HoSoBenhAnService.Require(r["TrangThai"].ToString()=="Chờ khám","Lịch này đã xử lý.");HoSoBenhAnService.Require(((DateTime)r["NgayHen"]).Date==DateTime.Today,"Chỉ tiếp nhận lịch trong ngày hôm nay.");HoSoBenhAnService.OpenVisit(r["MaHS"].ToString(),r["MaBS"].ToString(),DateTime.Now,r["LoaiKham"].ToString());r["TrangThai"]="Đã tiếp nhận";},RefreshAll));
 DanhMucService.VisibleButton(tabHen,"Khám trực tiếp",405,135,170,()=>DanhMucService.Run(()=>HoSoBenhAnService.OpenVisit(DanhMucService.Selected(hs),DanhMucService.Selected(bs),DateTime.Now,loai.Text),RefreshAll));
 DanhMucService.VisibleButton(tabHen,"Hủy lịch chọn",590,135,170,()=>{if(MessageBox.Show("Hủy lịch đã chọn?","Xác nhận",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;DanhMucService.Run(()=>{var r=DanhMucService.Selected(lich);HoSoBenhAnService.Require(r["TrangThai"].ToString()=="Chờ khám","Chỉ hủy lịch đang chờ.");r["TrangThai"]="Đã hủy";},RefreshAll);});
 PlaceGrid(tabHen,lich,195);Field(tabKham,"Triệu chứng",trieu,25,25);Field(tabKham,"Chẩn đoán",chan,430,25);
 DanhMucService.VisibleButton(tabKham,"Lưu khám",25,85,150,()=>DanhMucService.Run(()=>{var r=DanhMucService.Selected(kham);HoSoBenhAnService.EditableVisit(r["MaKham"].ToString());r["TrieuChung"]=DanhMucService.Text(trieu);r["ChanDoan"]=DanhMucService.Text(chan);},RefreshAll));
 DanhMucService.VisibleButton(tabKham,"Hoàn tất khám",190,85,180,()=>DanhMucService.Run(()=>HoSoBenhAnService.Complete(DanhMucService.Selected(kham)["MaKham"].ToString()),RefreshAll));PlaceGrid(tabKham,kham,145);
 kham.SelectionChanged+=(s,e)=>{if(kham.CurrentRow!=null&&kham.CurrentRow.DataBoundItem is DataRowView){var r=((DataRowView)kham.CurrentRow.DataBoundItem).Row;trieu.Text=r["TrieuChung"].ToString();chan.Text=r["ChanDoan"].ToString();}};
 Field(tabLuu,"Mã hồ sơ",tim,25,25);DanhMucService.VisibleButton(tabLuu,"Tìm",430,25,140,()=>DanhMucService.Grid(luu,string.IsNullOrWhiteSpace(tim.Text)?(object)Db.Table("PhieuKham"):DanhMucService.Filter("PhieuKham","MaHS",tim.Text.Trim())));DanhMucService.VisibleButton(tabLuu,"Xuất CSV",590,25,140,()=>DanhMucService.Export(luu));PlaceGrid(tabLuu,luu,100);RefreshAll(); }
 void Field(Control parent,string name,Control c,int x,int y) { parent.Controls.Add(new Label{Text=name,Location=new Point(x,y+5),AutoSize=true});c.SetBounds(x+125,y,250,30);parent.Controls.Add(c); }
 void PlaceGrid(Control p,DataGridView g,int y) { g.SetBounds(25,y,1250,530);g.Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;p.Controls.Add(g); }
 void RefreshAll() { DanhMucService.Combo(hs,"HoSo","MaHS","MaHS");DanhMucService.Combo(bs,"NhanVien","MaNV","HoTen");((DataView)bs.DataSource).RowFilter="VaiTro = 'Bác sĩ'";DanhMucService.Grid(lich,Db.Table("LichHen"));DanhMucService.Grid(kham,Db.Table("PhieuKham"));DanhMucService.Grid(luu,Db.Table("PhieuKham")); }
} }
namespace QuanLyBenhAn.Forms {
 partial class FrmKhamBenh {
  private System.ComponentModel.IContainer components=null;
  protected override void Dispose(bool disposing) { if(disposing&&components!=null)components.Dispose();base.Dispose(disposing); }
  private System.Windows.Forms.TabControl tabs;
  private System.Windows.Forms.TabPage tabHen,tabKham,tabLuu;
  private void InitializeComponent() {
   tabs=new System.Windows.Forms.TabControl();tabHen=new System.Windows.Forms.TabPage("Đặt lịch / Tiếp nhận");tabKham=new System.Windows.Forms.TabPage("Khám bệnh");tabLuu=new System.Windows.Forms.TabPage("Tra cứu bệnh án");
   tabs.Dock=System.Windows.Forms.DockStyle.Fill;tabs.Controls.AddRange(new System.Windows.Forms.Control[]{tabHen,tabKham,tabLuu});
   this.AutoScaleDimensions=new System.Drawing.SizeF(8F,16F);this.AutoScaleMode=System.Windows.Forms.AutoScaleMode.Font;this.ClientSize=new System.Drawing.Size(1364,842);this.Controls.Add(tabs);this.Text="Đặt lịch - Khám bệnh";
  }
 }
}