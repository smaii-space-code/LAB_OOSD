﻿namespace QuanLyBenhAn.Forms
{
    partial class FrmThanhToan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cboDat = new System.Windows.Forms.ComboBox();
            this.dgvHoSo = new System.Windows.Forms.DataGridView();
            this.HoSo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvBenhNhan = new System.Windows.Forms.DataGridView();
            this.dgvChiPhi = new System.Windows.Forms.DataGridView();
            this.XetNghiem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Loai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ChiPhiKhac = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MucDo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaChiPhi = new System.Windows.Forms.TextBox();
            this.txtSoHD = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMucDo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnThemChiPhi = new System.Windows.Forms.Button();
            this.btnLapHD = new System.Windows.Forms.Button();
            this.dgvHD = new System.Windows.Forms.DataGridView();
            this.HoaDon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhieuKham = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhiKham = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TienDV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TrangThai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnLuuTru = new System.Windows.Forms.Button();
            this.numChiPhi = new System.Windows.Forms.NumericUpDown();
            this.numPhiKham = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoSo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBenhNhan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiPhi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numChiPhi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPhiKham)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Phiếu khám:";
            // 
            // cboDat
            // 
            this.cboDat.FormattingEnabled = true;
            this.cboDat.Location = new System.Drawing.Point(178, 17);
            this.cboDat.Name = "cboDat";
            this.cboDat.Size = new System.Drawing.Size(197, 33);
            this.cboDat.TabIndex = 1;
            // 
            // dgvHoSo
            // 
            this.dgvHoSo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoSo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HoSo,
            this.DonGia});
            this.dgvHoSo.Location = new System.Drawing.Point(29, 75);
            this.dgvHoSo.Name = "dgvHoSo";
            this.dgvHoSo.RowHeadersWidth = 51;
            this.dgvHoSo.RowTemplate.Height = 24;
            this.dgvHoSo.Size = new System.Drawing.Size(304, 217);
            this.dgvHoSo.TabIndex = 2;
            // 
            // HoSo
            // 
            this.HoSo.HeaderText = "Hồ sơ";
            this.HoSo.MinimumWidth = 6;
            this.HoSo.Name = "HoSo";
            this.HoSo.Width = 125;
            // 
            // DonGia
            // 
            this.DonGia.HeaderText = "Phí khám";
            this.DonGia.MinimumWidth = 6;
            this.DonGia.Name = "DonGia";
            this.DonGia.Width = 125;
            // 
            // dgvBenhNhan
            // 
            this.dgvBenhNhan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBenhNhan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.XetNghiem,
            this.Loai,
            this.TinhTrang});
            this.dgvBenhNhan.Location = new System.Drawing.Point(405, 75);
            this.dgvBenhNhan.Name = "dgvBenhNhan";
            this.dgvBenhNhan.RowHeadersWidth = 51;
            this.dgvBenhNhan.RowTemplate.Height = 24;
            this.dgvBenhNhan.Size = new System.Drawing.Size(428, 217);
            this.dgvBenhNhan.TabIndex = 3;
            // 
            // dgvChiPhi
            // 
            this.dgvChiPhi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiPhi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ChiPhiKhac,
            this.MucDo,
            this.SoTien});
            this.dgvChiPhi.Location = new System.Drawing.Point(909, 75);
            this.dgvChiPhi.Name = "dgvChiPhi";
            this.dgvChiPhi.RowHeadersWidth = 51;
            this.dgvChiPhi.RowTemplate.Height = 24;
            this.dgvChiPhi.Size = new System.Drawing.Size(429, 217);
            this.dgvChiPhi.TabIndex = 4;
            // 
            // XetNghiem
            // 
            this.XetNghiem.HeaderText = "Xét nghiệm";
            this.XetNghiem.MinimumWidth = 6;
            this.XetNghiem.Name = "XetNghiem";
            this.XetNghiem.Width = 125;
            // 
            // Loai
            // 
            this.Loai.HeaderText = "Loại";
            this.Loai.MinimumWidth = 6;
            this.Loai.Name = "Loai";
            this.Loai.Width = 125;
            // 
            // TinhTrang
            // 
            this.TinhTrang.HeaderText = "Tình trạng";
            this.TinhTrang.MinimumWidth = 6;
            this.TinhTrang.Name = "TinhTrang";
            this.TinhTrang.Width = 125;
            // 
            // ChiPhiKhac
            // 
            this.ChiPhiKhac.HeaderText = "Chi phí khác";
            this.ChiPhiKhac.MinimumWidth = 6;
            this.ChiPhiKhac.Name = "ChiPhiKhac";
            this.ChiPhiKhac.Width = 125;
            // 
            // MucDo
            // 
            this.MucDo.HeaderText = "Nội dung";
            this.MucDo.MinimumWidth = 6;
            this.MucDo.Name = "MucDo";
            this.MucDo.Width = 125;
            // 
            // SoTien
            // 
            this.SoTien.HeaderText = "Số tiền";
            this.SoTien.MinimumWidth = 6;
            this.SoTien.Name = "SoTien";
            this.SoTien.Width = 125;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 324);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Mã thu thêm:";
            // 
            // txtMaChiPhi
            // 
            this.txtMaChiPhi.Location = new System.Drawing.Point(178, 319);
            this.txtMaChiPhi.Name = "txtMaChiPhi";
            this.txtMaChiPhi.Size = new System.Drawing.Size(197, 30);
            this.txtMaChiPhi.TabIndex = 6;
            // 
            // txtSoHD
            // 
            this.txtSoHD.Location = new System.Drawing.Point(178, 381);
            this.txtSoHD.Name = "txtSoHD";
            this.txtSoHD.Size = new System.Drawing.Size(197, 30);
            this.txtSoHD.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 386);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Số hóa đơn:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(412, 386);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 25);
            this.label4.TabIndex = 11;
            this.label4.Text = "Phí khám:";
            // 
            // txtMucDo
            // 
            this.txtMucDo.Location = new System.Drawing.Point(581, 319);
            this.txtMucDo.Name = "txtMucDo";
            this.txtMucDo.Size = new System.Drawing.Size(197, 30);
            this.txtMucDo.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(412, 324);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Nội dung:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(824, 324);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "Số tiền:";
            // 
            // btnThemChiPhi
            // 
            this.btnThemChiPhi.Location = new System.Drawing.Point(1153, 313);
            this.btnThemChiPhi.Name = "btnThemChiPhi";
            this.btnThemChiPhi.Size = new System.Drawing.Size(202, 36);
            this.btnThemChiPhi.TabIndex = 15;
            this.btnThemChiPhi.Text = "Thêm chi phí";
            this.btnThemChiPhi.UseVisualStyleBackColor = true;
            // 
            // btnLapHD
            // 
            this.btnLapHD.Location = new System.Drawing.Point(876, 375);
            this.btnLapHD.Name = "btnLapHD";
            this.btnLapHD.Size = new System.Drawing.Size(202, 36);
            this.btnLapHD.TabIndex = 16;
            this.btnLapHD.Text = "Lập hóa đơn";
            this.btnLapHD.UseVisualStyleBackColor = true;
            // 
            // dgvHD
            // 
            this.dgvHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HoaDon,
            this.PhieuKham,
            this.PhiKham,
            this.TienDV,
            this.TongTien,
            this.TrangThai});
            this.dgvHD.Location = new System.Drawing.Point(60, 438);
            this.dgvHD.Name = "dgvHD";
            this.dgvHD.RowHeadersWidth = 51;
            this.dgvHD.RowTemplate.Height = 24;
            this.dgvHD.Size = new System.Drawing.Size(1253, 301);
            this.dgvHD.TabIndex = 17;
            // 
            // HoaDon
            // 
            this.HoaDon.HeaderText = "Hóa đơn";
            this.HoaDon.MinimumWidth = 6;
            this.HoaDon.Name = "HoaDon";
            this.HoaDon.Width = 200;
            // 
            // PhieuKham
            // 
            this.PhieuKham.HeaderText = "Phiếu khám";
            this.PhieuKham.MinimumWidth = 6;
            this.PhieuKham.Name = "PhieuKham";
            this.PhieuKham.Width = 200;
            // 
            // PhiKham
            // 
            this.PhiKham.HeaderText = "Phí khám";
            this.PhiKham.MinimumWidth = 6;
            this.PhiKham.Name = "PhiKham";
            this.PhiKham.Width = 200;
            // 
            // TienDV
            // 
            this.TienDV.HeaderText = "Tiền dịch vụ";
            this.TienDV.MinimumWidth = 6;
            this.TienDV.Name = "TienDV";
            this.TienDV.Width = 200;
            // 
            // TongTien
            // 
            this.TongTien.HeaderText = "Tổng tiền";
            this.TongTien.MinimumWidth = 6;
            this.TongTien.Name = "TongTien";
            this.TongTien.Width = 200;
            // 
            // TrangThai
            // 
            this.TrangThai.HeaderText = "Trạng thái";
            this.TrangThai.MinimumWidth = 6;
            this.TrangThai.Name = "TrangThai";
            this.TrangThai.Width = 200;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(581, 764);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(197, 30);
            this.textBox6.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(412, 769);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 25);
            this.label7.TabIndex = 20;
            this.label7.Text = "Số tiền:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(178, 764);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(197, 30);
            this.textBox7.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 769);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 25);
            this.label8.TabIndex = 18;
            this.label8.Text = "Hình thức:";
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Location = new System.Drawing.Point(829, 758);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(202, 36);
            this.btnThanhToan.TabIndex = 22;
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            // 
            // btnLuuTru
            // 
            this.btnLuuTru.Location = new System.Drawing.Point(1079, 758);
            this.btnLuuTru.Name = "btnLuuTru";
            this.btnLuuTru.Size = new System.Drawing.Size(202, 36);
            this.btnLuuTru.TabIndex = 23;
            this.btnLuuTru.Text = "Lưu trữ bệnh án";
            this.btnLuuTru.UseVisualStyleBackColor = true;
            // 
            // numChiPhi
            // 
            this.numChiPhi.Location = new System.Drawing.Point(909, 319);
            this.numChiPhi.Name = "numChiPhi";
            this.numChiPhi.Size = new System.Drawing.Size(169, 30);
            this.numChiPhi.TabIndex = 24;
            // 
            // numPhiKham
            // 
            this.numPhiKham.Location = new System.Drawing.Point(581, 381);
            this.numPhiKham.Name = "numPhiKham";
            this.numPhiKham.Size = new System.Drawing.Size(197, 30);
            this.numPhiKham.TabIndex = 25;
            // 
            // FrmThanhToan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.numPhiKham);
            this.Controls.Add(this.numChiPhi);
            this.Controls.Add(this.btnLuuTru);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dgvHD);
            this.Controls.Add(this.btnLapHD);
            this.Controls.Add(this.btnThemChiPhi);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtMucDo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSoHD);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMaChiPhi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvChiPhi);
            this.Controls.Add(this.dgvBenhNhan);
            this.Controls.Add(this.dgvHoSo);
            this.Controls.Add(this.cboDat);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmThanhToan";
            this.Text = "Thanh toán - Lưu trữ bệnh án";
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoSo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBenhNhan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiPhi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numChiPhi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPhiKham)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboDat;
        private System.Windows.Forms.DataGridView dgvHoSo;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoSo;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonGia;
        private System.Windows.Forms.DataGridView dgvBenhNhan;
        private System.Windows.Forms.DataGridViewTextBoxColumn XetNghiem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Loai;
        private System.Windows.Forms.DataGridViewTextBoxColumn TinhTrang;
        private System.Windows.Forms.DataGridView dgvChiPhi;
        private System.Windows.Forms.DataGridViewTextBoxColumn ChiPhiKhac;
        private System.Windows.Forms.DataGridViewTextBoxColumn MucDo;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoTien;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaChiPhi;
        private System.Windows.Forms.TextBox txtSoHD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMucDo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnThemChiPhi;
        private System.Windows.Forms.Button btnLapHD;
        private System.Windows.Forms.DataGridView dgvHD;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoaDon;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhieuKham;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhiKham;
        private System.Windows.Forms.DataGridViewTextBoxColumn TienDV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongTien;
        private System.Windows.Forms.DataGridViewTextBoxColumn TrangThai;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnLuuTru;
        private System.Windows.Forms.NumericUpDown numChiPhi;
        private System.Windows.Forms.NumericUpDown numPhiKham;
    }
}