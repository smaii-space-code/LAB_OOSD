﻿using System; using System.Data; using System.Linq; using QuanLyBenhAn.Data;
namespace QuanLyBenhAn.Services {
 public static class HoSoBenhAnService {
  public static DataRow Find(string table,string id) { var row=Db.Table(table).Rows.Find(id); if(row==null) throw new Exception("Không tìm thấy "+table+": "+id); return row; }
  public static void Require(bool ok,string message) { if(!ok) throw new Exception(message); }
  public static string Id(string prefix) { return prefix+Guid.NewGuid().ToString("N").Substring(0,8).ToUpperInvariant(); }
  public static void Add(string table,params object[] values) { Require(values[0]!=null&&!string.IsNullOrWhiteSpace(values[0].ToString()),"Mã không được trống."); Require(Db.Table(table).Rows.Find(values[0])==null,"Mã đã tồn tại."); Db.Table(table).Rows.Add(values); }
  public static bool HasFee(string hs, DateTime date) { return Db.Table("ThuPhi").AsEnumerable().Any(r=>r.Field<string>("MaHS")==hs&&r.Field<DateTime>("NgayThu").Date<=date.Date&&r.Field<DateTime>("DenNgay").Date>=date.Date); }
  public static bool HasQuarter(string hs,DateTime date) { return Db.Table("PhieuKham").AsEnumerable().Any(r=>r.Field<string>("MaHS")==hs && r.Field<string>("LoaiKham")=="Định kỳ"&&r.Field<DateTime>("NgayKham").Year==date.Year&&(r.Field<DateTime>("NgayKham").Month-1)/3==(date.Month-1)/3); }
  public static void OpenVisit(string hs,string bs,DateTime date,string type) {
   Find("HoSo",hs); var doctor=Find("NhanVien",bs); Require(doctor["VaiTro"].ToString()=="Bác sĩ","Chọn nhân viên có vai trò Bác sĩ.");
   Require(HasFee(hs,date),"Hồ sơ chưa đóng phí năm hoặc đã hết hạn.");
   Require(!Db.Table("PhieuKham").AsEnumerable().Any(r=>r.Field<string>("MaHS")==hs&&r.Field<string>("TrangThai")=="Đang khám"),"Hồ sơ đang có một lượt khám chưa hoàn tất.");
   if(type=="Định kỳ") Require(!HasQuarter(hs,date),"Đã sử dụng lượt khám định kỳ trong quý này.");
   Add("PhieuKham",Id("PK"),hs,bs,date,type,"","","Đang khám");
  }
  public static void EditableVisit(string pk) { Require(Find("PhieuKham",pk)["TrangThai"].ToString()=="Đang khám","Chỉ sửa được lượt đang khám."); }
  public static void Complete(string pk) { var row=Find("PhieuKham",pk); EditableVisit(pk); Require(!string.IsNullOrWhiteSpace(row["ChanDoan"].ToString()),"Cần nhập chẩn đoán."); Require(!Db.Table("ChiDinh").AsEnumerable().Any(r=>r.Field<string>("MaKham")==pk&&string.IsNullOrWhiteSpace(r.Field<string>("KetQua"))),"Còn xét nghiệm chưa có kết quả."); row["TrangThai"]="Đã khám"; }
  public static decimal Sum(string table,string pk,string field) { return Db.Table(table).AsEnumerable().Where(r=>r.Field<string>("MaKham")==pk).Sum(r=>r.Field<decimal>(field)); }
  public static void Invoice(string id,string pk,decimal examFee) {
   var visit=Find("PhieuKham",pk); Require(visit["TrangThai"].ToString()=="Đã khám","Hoàn tất khám trước khi lập hóa đơn.");
   Require(!Db.Table("HoaDon").AsEnumerable().Any(r=>r.Field<string>("MaKham")==pk),"Phiếu khám đã có hóa đơn.");
   if(visit["LoaiKham"].ToString()=="Định kỳ") examFee=0;
   decimal lab=Sum("ChiDinh",pk,"ThanhTien"), other=Sum("ChiPhi",pk,"SoTien");
   Add("HoaDon",id,pk,DateTime.Now,examFee,lab,other,examFee+lab+other,"Chưa thanh toán","");
  }
  public static void Commit(Action action) {
   var before=Db.Store.Copy(); try { action(); Db.Save(); }
   catch { Db.Store.Clear(); Db.Store.Merge(before,false,MissingSchemaAction.Ignore); throw; }
  }
 }
}