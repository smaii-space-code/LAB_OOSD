﻿using System; using QuanLyBenhAn.Data;
namespace QuanLyBenhAn.Services {
 public static class DichVuService {
  public static void ChiDinh(string maKham,string maDV,DateTime ngay,int soLuong) {
   HoSoBenhAnService.EditableVisit(maKham);
   HoSoBenhAnService.Require(soLuong>0,"Số lượng phải lớn hơn 0.");
   decimal gia=Convert.ToDecimal(HoSoBenhAnService.Find("DichVu",maDV)["DonGia"]);
   HoSoBenhAnService.Add("ChiDinh",HoSoBenhAnService.Id("CD"),maKham,maDV,ngay.Date,soLuong,gia,gia*soLuong,"");
  }
 }
}