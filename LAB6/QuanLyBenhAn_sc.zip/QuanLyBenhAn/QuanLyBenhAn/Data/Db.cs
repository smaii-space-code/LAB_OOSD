﻿using System;
using System.Data;
using System.IO;
namespace QuanLyBenhAn.Data {
 public static class Db {
  public static readonly DataSet Store = new DataSet("QuanLyBenhAn");
  public static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "QuanLyBenhAn_Lab");
  public static string FilePath { get { return Path.Combine(Folder,"DuLieu.xml"); } }
  public static DataTable Table(string name) { return Store.Tables[name]; }
  static void Define(string name, params string[] fields) {
   var t=Store.Tables.Add(name); foreach(var f in fields) { var a=f.Split(':'); t.Columns.Add(a[0],a.Length==1?typeof(string):a[1]=="n"?typeof(decimal):a[1]=="d"?typeof(DateTime):typeof(int)); }
   t.PrimaryKey=new[]{t.Columns[0]};
  }
  public static void Initialize() {
   Define("Khoa","MaKhoa","TenKhoa"); Define("NhanVien","MaNV","HoTen","VaiTro","SoDienThoai");
   Define("LoaiHoSo","MaLoai","TenLoai"); Define("DichVu","MaDV","TenDV","DonViTinh","DonGia:n"); Define("MucPhi","MaPhi","DoiTuong","TenPhi","SoTien:n");
   Define("BenhNhan","MaBN","HoTen","GioiTinh","NamSinh:i"); Define("HoSo","MaHS","MaBN","NamLap:i","PhiNam:n","TrangThai");
   Define("ThuPhi","MaThu","MaBN","MaHS","NgayThu:d","DenNgay:d","SoTien:n","MaNV","GhiChu");
   Define("LichHen","MaHen","MaHS","MaBS","NgayHen:d","LoaiKham","TrangThai");
   Define("PhieuKham","MaKham","MaHS","MaBS","NgayKham:d","LoaiKham","TrieuChung","ChanDoan","TrangThai");
   Define("ChiDinh","MaCD","MaKham","MaDV","Ngay:d","SoLuong:i","DonGia:n","ThanhTien:n","KetQua");
   Define("DonThuoc","MaDon","MaKham","NoiDung","Ngay:d");
   Define("ChiPhi","MaCP","MaKham","NoiDung","SoTien:n");
   Define("HoaDon","MaHD","MaKham","Ngay:d","PhiKham:n","PhiXN:n","PhiKhac:n","TongTien:n","TrangThai","HinhThuc");
   if(File.Exists(FilePath)) { Store.ReadXml(FilePath,XmlReadMode.IgnoreSchema); return; }
   Table("Khoa").Rows.Add("K01","Nội tổng quát"); Table("Khoa").Rows.Add("K02","Ngoại tổng quát");
   Table("NhanVien").Rows.Add("BS01","Bác sĩ minh họa","Bác sĩ",""); Table("NhanVien").Rows.Add("NV01","Nhân viên minh họa","Tiếp nhận","");
   Table("LoaiHoSo").Rows.Add("L01","Bệnh án ngoại trú"); Table("DichVu").Rows.Add("XN01","Xét nghiệm minh họa","Lần",50000m);
   Table("MucPhi").Rows.Add("P01","Thông thường","Phí hồ sơ năm",200000m);
   Table("BenhNhan").Rows.Add("BN001","Bệnh nhân minh họa","Nam",2000);
   Table("HoSo").Rows.Add("HS001","BN001",DateTime.Today.Year,200000m,"Đang quản lý"); Save();
  }
  // Save to a temporary file and atomically replace the last committed version.
  public static void Save() {
   Directory.CreateDirectory(Folder); string tmp=FilePath+".tmp";
   try { Store.WriteXml(tmp,XmlWriteMode.WriteSchema); if(File.Exists(FilePath)) File.Replace(tmp,FilePath,FilePath+".bak"); else File.Move(tmp,FilePath); }
   finally { if(File.Exists(tmp)) File.Delete(tmp); }
  }
 }
}