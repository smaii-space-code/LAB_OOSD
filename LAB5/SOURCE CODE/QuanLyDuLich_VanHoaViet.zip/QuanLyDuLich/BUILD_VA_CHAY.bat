@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
 echo Khong tim thay compiler. Mo QuanLyDuLich.sln bang Visual Studio.
 pause
 exit /b 1
)
if not exist QuanLyDuLich\bin\Release mkdir QuanLyDuLich\bin\Release
"%CSC%" /nologo /target:winexe /out:QuanLyDuLich\bin\Release\QuanLyDuLich.exe /r:System.dll /r:System.Core.dll /r:System.Data.dll /r:System.Data.DataSetExtensions.dll /r:System.Xml.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll QuanLyDuLich\Program.cs QuanLyDuLich\Data\Db.cs QuanLyDuLich\Services\DuLichService.cs QuanLyDuLich\Services\BaoCaoService.cs QuanLyDuLich\Forms\FrmMain.cs QuanLyDuLich\Forms\FrmEditor.cs QuanLyDuLich\Properties\AssemblyInfo.cs
if errorlevel 1 (
 pause
 exit /b 1
)
copy /y QuanLyDuLich\App.config QuanLyDuLich\bin\Release\QuanLyDuLich.exe.config >nul
start "" "QuanLyDuLich\bin\Release\QuanLyDuLich.exe"
