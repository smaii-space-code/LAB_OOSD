# Kết quả kiểm tra bản giao

- Đã kiểm tra solution/project tham chiếu đúng các file C# và không có file nguồn bị bỏ sót.
- Đã kiểm tra cấu trúc XML của project và App.config.
- Đã rà soát không còn namespace, tên lớp hoặc dữ liệu nghiệp vụ của đề tài cũ trong mã nguồn giao.
- Đã cung cấp bộ kiểm thử nghiệp vụ `Tests/BusinessTests.cs` và lệnh chạy `KIEM_TRA.bat`.
- **Chưa biên dịch hoặc chạy được ứng dụng WinForms/bộ kiểm thử trong môi trường thực hiện này** vì chưa có compiler/runtime .NET phù hợp. Chưa xác minh giao diện trên Windows. Cần Rebuild Solution và chạy KIEM_TRA.bat trên Windows trước khi nộp.
- HTML quảng cáo là tệp xuất tĩnh; khảo sát do người dùng tự gửi. Các giới hạn và quy ước nghiệp vụ được ghi trong HUONG_DAN.md.
