@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
 echo Khong tim thay C# compiler. Hay build bang Visual Studio.
 pause
 exit /b 1
)
if not exist Tests\bin mkdir Tests\bin
"%CSC%" /nologo /target:exe /out:Tests\bin\BusinessTests.exe /r:System.dll /r:System.Core.dll /r:System.Data.dll /r:System.Data.DataSetExtensions.dll /r:System.Xml.dll QuanLyDuLich\Data\Db.cs QuanLyDuLich\Services\DuLichService.cs QuanLyDuLich\Services\BaoCaoService.cs Tests\BusinessTests.cs
if errorlevel 1 (
 pause
 exit /b 1
)
Tests\bin\BusinessTests.exe
set "TEST_RESULT=%ERRORLEVEL%"
pause
exit /b %TEST_RESULT%
