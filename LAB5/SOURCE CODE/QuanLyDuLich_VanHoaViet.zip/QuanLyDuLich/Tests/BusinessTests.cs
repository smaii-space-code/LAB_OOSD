﻿using System;
using System.Data;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using QuanLyDuLich.Data;
using QuanLyDuLich.Services;
class BusinessTests {
 static int passed;
 static void OK(bool test,string name) { if(!test) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); passed++; }
 static void Reject(Action action,string name) { bool rejected=false; try {action();} catch(InvalidOperationException) {rejected=true;} OK(rejected,name); }
 static void Add(string t,params object[] pairs) { var d=new Dictionary<string,object>(); foreach(DataColumn c in Db.Table(t).Columns) d[c.ColumnName]=c.DefaultValue; for(int i=0;i<pairs.Length;i+=2) d[(string)pairs[i]]=pairs[i+1]; DuLichService.SaveRow(t,null,d); }
 static void Booking(string id,string type,int people,bool insurance) {
  Add("DangKy","MaDK",id,"Loai",type,"MaKH","K1","MaTour","T1","MaChuyen",type=="Lẻ"?"C1":"","NgayDi",DateTime.Today,"NgayVe",DateTime.Today,"SoNguoi",people,"DonGia",100m,"BaoHiem",insurance,"DiaDiemDon",type=="Đoàn"?"Trụ sở đoàn":"","MaDiemDon",type=="Lẻ"?"D1":"","MaDiemBan",type=="Lẻ"?"B1":"","TrangThai","Nháp");
 }
 static void Pay(string id,string booking,string type,decimal amount) { Add("ThuTien","MaThu",id,"MaDK",booking,"NgayThu",DateTime.Today,"LoaiThu",type,"SoTien",amount,"HinhThuc","Tiền mặt"); }
 static void Assign(string id,string nv,string type,string target) { Add("PhanCong","MaPC",id,"MaNV",nv,"Loai",type,"MaDoiTuong",target,"ThuLao",200m); }
 static int Main() {
  var folder=Path.Combine(Path.GetTempPath(),"DuLichTests_"+Guid.NewGuid().ToString("N")); Db.Folder=folder;
  try {
   Db.Initialize();
   Add("Tour","MaTour","T1","TenTour","Tour <kiểm tra>","SoNgay",1,"SoDem",0,"DonGia",100m);
   Add("HanhTrinh","MaChang","H1","MaTour","T1","ThuTu",1,"NoiDi","TP.HCM","NoiDen","Củ Chi","PhuongTien","Xe du lịch");
   Add("HanhTrinh","MaChang","H2","MaTour","T1","ThuTu",2,"NoiDi","Củ Chi","NoiDen","TP.HCM","PhuongTien","Xe du lịch");
   Add("DiemThamQuan","MaDiem","DT1","TenDiem","Điểm test","DiaDiem","Củ Chi","NoiDung","Nội dung","YNghia","Ý nghĩa");
   Add("TourDiem","MaCT","CT1","MaTour","T1","MaDiem","DT1","ThuTu",1);
   Add("DiemBanVe","MaDiemBan","B1","TenDiemBan","Quầy vé","DiaChi","TP.HCM","DienThoai","000");
   Add("DiemDon","MaDiemDon","D1","TenDiemDon","Điểm đón","DiaChi","TP.HCM");
   Add("KhachHang","MaKH","K1","TenCoQuan","Đoàn kiểm thử","NguoiDaiDien","Khách kiểm thử","DiaChi","TP.HCM","DienThoai","000");
   foreach(string id in new[]{"N1","N2","N3"}) Add("NhanVien","MaNV",id,"HoTen",id,"DienThoai","000","LuongCoBan",1000m);
   Add("Chuyen","MaChuyen","C1","MaTour","T1","NgayDi",DateTime.Today,"NgayVe",DateTime.Today,"TrangThai","Dự kiến");
   Reject(()=>Booking("INVALID","Đoàn",12,false),"Đoàn 12 người bị từ chối"); OK(Db.Table("DangKy").Rows.Find("INVALID")==null,"Rollback dữ liệu lỗi");
   Booking("LE","Lẻ",12,false); Reject(()=>DuLichService.Confirm("LE"),"Khách lẻ chưa trả tiền không xác nhận");
   Reject(()=>Pay("OVER","LE","Tiền vé",1201m),"Không thu vượt tổng tiền");
   Pay("P1","LE","Tiền vé",1200m); DuLichService.Confirm("LE"); OK(DuLichService.S(DuLichService.Find("DangKy","LE"),"TrangThai")=="Đã xác nhận","Khách lẻ 12 người xác nhận sau trả đủ");
   Reject(()=>DuLichService.Delete("ThuTien","P1"),"Không xóa phiếu thu");
   Reject(()=>DuLichService.Cancel("DangKy","LE"),"Không tự hủy vé đã trả tiền khi chưa có chính sách hoàn");
   Booking("DOAN","Đoàn",13,true); Pay("P2","DOAN","Đặt cọc",300m);
   Reject(()=>DuLichService.Confirm("DOAN"),"Bảo hiểm thiếu danh sách không xác nhận");
   for(int i=0;i<13;i++) Add("ThanhVien","MaTV","TV"+i,"MaDK","DOAN","HoTen","Người "+i,"NgaySinh",new DateTime(2000,1,1),"GiayTo","TEST"+i);
   DuLichService.Confirm("DOAN"); OK(DuLichService.S(DuLichService.Find("DangKy","DOAN"),"TrangThai")=="Đã xác nhận","Đoàn đủ bảo hiểm và cọc được xác nhận");
   Reject(()=>Pay("EARLY","DOAN","Thanh toán đoàn",1000m),"Chưa kết thúc không thanh toán đoàn");
   Assign("PC1","N1","Chuyến","C1"); Reject(()=>Assign("PC2","N2","Chuyến","C1"),"Chuyến khách lẻ tối đa một hướng dẫn viên");
   Reject(()=>Assign("PC3","N1","Đoàn","DOAN"),"Chặn trùng lịch hướng dẫn viên");
   Assign("PC4","N2","Đoàn","DOAN"); Assign("PC5","N3","Đoàn","DOAN");
   DuLichService.Complete("Chuyen","C1"); DuLichService.Complete("DangKy","DOAN"); Pay("P3","DOAN","Thanh toán đoàn",1000m);
   OK(DuLichService.Paid("DOAN")==1300m,"Đoàn thanh toán đủ sau hoàn tất");
   var salary=BaoCaoService.Salary(DateTime.Today.Month,DateTime.Today.Year); OK(salary.Rows.Cast<DataRow>().All(r=>Convert.ToDecimal(r["Tổng lương"])==1200m),"Lương cơ bản cộng lương tour hoàn tất");
   Add("KhaoSat","MaKS","KS1","MaDK","DOAN","NgayGui",DateTime.Today,"TrangThai","Đã trả lời","Diem",5,"GopY","Tốt");
   Reject(()=>Add("KhaoSat","MaKS","KS2","MaDK","DOAN","NgayGui",DateTime.Today,"TrangThai","Đã trả lời","Diem",6),"Chặn điểm khảo sát ngoài 1–5");
   Booking("HUY","Đoàn",13,false); Pay("P4","HUY","Đặt cọc",100m); DuLichService.Confirm("HUY"); DuLichService.Cancel("DangKy","HUY");
   var debt=BaoCaoService.Debt().Rows.Cast<DataRow>().Single(r=>r[0].ToString()=="HUY"); OK(Convert.ToDecimal(debt["Còn phải thu"])==0&&Convert.ToDecimal(debt["Cọc mất khi hủy"])==100,"Hủy đoàn mất cọc và hết công nợ còn lại");
   Reject(()=>DuLichService.Delete("Tour","T1"),"Không xóa tour đã sử dụng");
   string html=Path.Combine(folder,"catalog.html"); BaoCaoService.Catalog(html); OK(File.ReadAllText(html).Contains("&lt;kiểm tra&gt;"),"Mã hóa HTML nội dung nhập");
   var saved=new DataSet(); saved.ReadXml(Db.FilePath,XmlReadMode.ReadSchema); OK(saved.Tables["ThuTien"].Rows.Count==4,"Dữ liệu XML lưu đủ phiếu thu hợp lệ");
   Console.WriteLine("TOTAL PASS: "+passed); return 0;
  } catch(Exception ex) {Console.Error.WriteLine(ex); return 1;}
  finally {if(Directory.Exists(folder)) Directory.Delete(folder,true);}
 }
}
