﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using QuanLyDuLich.Data;
using QuanLyDuLich.Services;
namespace QuanLyDuLich.Forms {
 public class FrmEditor : Form {
  readonly string table, id;
  readonly Dictionary<string,Control> inputs=new Dictionary<string,Control>();
  static readonly Dictionary<string,string> refs=new Dictionary<string,string> { {"MaTour","Tour"},{"MaKH","KhachHang"},{"MaNV","NhanVien"},{"MaDK","DangKy"},{"MaChuyen","Chuyen"},{"MaDiem","DiemThamQuan"},{"MaDiemBan","DiemBanVe"},{"MaDiemDon","DiemDon"} };
  public FrmEditor(string table,string id) {
   this.table=table; this.id=id; var t=Db.Table(table); var row=id==null?null:DuLichService.Find(table,id);
   Text=(id==null?"Thêm — ":"Sửa — ")+Db.Titles[table]; Size=new Size(790,730); MinimumSize=new Size(650,500); StartPosition=FormStartPosition.CenterParent; Font=new Font("Segoe UI",10);
   var bottom=new FlowLayoutPanel { Dock=DockStyle.Bottom, Height=55, Padding=new Padding(8), FlowDirection=FlowDirection.RightToLeft };
   var save=new Button { Text="Lưu dữ liệu", Width=130, Height=32 }; save.Click+=(s,e)=>Save();
   var cancel=new Button {Text="Đóng", Width=95,Height=32,DialogResult=DialogResult.Cancel}; bottom.Controls.Add(save); bottom.Controls.Add(cancel); Controls.Add(bottom); CancelButton=cancel;
   var panel=new TableLayoutPanel {Dock=DockStyle.Fill,AutoScroll=true,ColumnCount=2,Padding=new Padding(16)};
   panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,270)); panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100)); Controls.Add(panel); panel.BringToFront();
   int index=0;
   foreach(DataColumn c in t.Columns) {
    Control input; object val=row==null?c.DefaultValue:row[c]; string[] choices=Choices(table,c.ColumnName);
    if(c.Ordinal==0) val=row==null?DuLichService.Id(table):val;
    if(c.DataType==typeof(bool)) input=new CheckBox { Checked=Convert.ToBoolean(val),AutoSize=true };
    else if(c.DataType==typeof(DateTime)) input=new DateTimePicker { Format=DateTimePickerFormat.Custom,CustomFormat="dd/MM/yyyy",Value=Convert.ToDateTime(val) };
    else if(c.DataType==typeof(int)||c.DataType==typeof(decimal)) input=new NumericUpDown {Maximum=c.DataType==typeof(int)?100000:1000000000000m,Minimum=0,DecimalPlaces=c.DataType==typeof(decimal)?2:0,ThousandsSeparator=true,Value=Convert.ToDecimal(val)};
    else if(c.Ordinal!=0&&refs.ContainsKey(c.ColumnName)) {
     var combo=new ComboBox {DropDownStyle=ComboBoxStyle.DropDownList,DisplayMember="Label",ValueMember="Key",DropDownWidth=500};
     var list=new List<Choice> {new Choice("","(Không chọn)")};
     foreach(DataRow rr in Db.Table(refs[c.ColumnName]).Rows) {
      string label=Convert.ToString(rr[0]); if(rr.Table.Columns.Count>1) label+=" — "+Convert.ToString(rr[1]);
      if(rr.Table.Columns.Contains("NguoiDaiDien")) label+=" — "+rr["NguoiDaiDien"];
      list.Add(new Choice(Convert.ToString(rr[0]),label));
     }
     combo.DataSource=list; combo.SelectedValue=Convert.ToString(val); input=combo;
    } else if(choices!=null) {
     var combo=new ComboBox {DropDownStyle=ComboBoxStyle.DropDownList}; combo.Items.AddRange(choices); combo.SelectedItem=Convert.ToString(val); if(combo.SelectedIndex<0) combo.SelectedIndex=0; input=combo;
    } else input=new TextBox {Text=Convert.ToString(val),Multiline=c.ColumnName=="GopY"||c.ColumnName=="MoTa"||c.ColumnName=="NoiDung"||c.ColumnName=="GhiChu",ScrollBars=ScrollBars.Vertical};
    input.Dock=DockStyle.Fill; input.Margin=new Padding(4,5,4,5);
    if(c.Ordinal==0&&row!=null) input.Enabled=false;
    if(c.ColumnName=="TrangThai"&&(table=="DangKy"||table=="Chuyen")) input.Enabled=false;
    inputs.Add(c.ColumnName,input);
    panel.RowStyles.Add(new RowStyle(SizeType.Absolute,input is TextBox&&((TextBox)input).Multiline?80:43));
    panel.Controls.Add(new Label {Text=c.Caption,AutoSize=true,Anchor=AnchorStyles.Left},0,index); panel.Controls.Add(input,1,index++);
   }
   if(table=="DangKy") {
    var tour=(ComboBox)inputs["MaTour"]; tour.SelectedValueChanged+=(s,e)=> { if(id==null&&tour.SelectedValue!=null&&tour.SelectedValue.ToString()!="") ((NumericUpDown)inputs["DonGia"]).Value=DuLichService.N(DuLichService.Find("Tour",tour.SelectedValue.ToString()),"DonGia"); };
    var loai=(ComboBox)inputs["Loai"]; var chuyen=(ComboBox)inputs["MaChuyen"];
    Action sync=()=> {
     bool le=Convert.ToString(loai.SelectedItem)=="Lẻ";
     foreach(var name in new[]{"MaChuyen","MaDiemDon","MaDiemBan"}) {inputs[name].Enabled=le; if(!le) ((ComboBox)inputs[name]).SelectedValue="";}
     inputs["DiaDiemDon"].Enabled=!le; inputs["NgayDi"].Enabled=!le; inputs["NgayVe"].Enabled=!le;
     if(le&&chuyen.SelectedValue!=null&&chuyen.SelectedValue.ToString()!="") { var c=DuLichService.Find("Chuyen",chuyen.SelectedValue.ToString()); tour.SelectedValue=c["MaTour"].ToString(); ((DateTimePicker)inputs["NgayDi"]).Value=DuLichService.D(c,"NgayDi"); ((DateTimePicker)inputs["NgayVe"]).Value=DuLichService.D(c,"NgayVe"); }
    };
    loai.SelectedIndexChanged+=(s,e)=>sync(); chuyen.SelectedValueChanged+=(s,e)=>sync(); sync();
   }
   if(table=="PhanCong") {
    var oldInput=inputs["MaDoiTuong"]; var combo=new ComboBox {Dock=DockStyle.Fill,DropDownStyle=ComboBoxStyle.DropDownList,DisplayMember="Label",ValueMember="Key",Margin=oldInput.Margin};
    var pos=panel.GetPositionFromControl(oldInput); panel.Controls.Remove(oldInput); oldInput.Dispose(); panel.Controls.Add(combo,pos.Column,pos.Row); inputs["MaDoiTuong"]=combo;
    Action sync=()=> { string target=Convert.ToString(((ComboBox)inputs["Loai"]).SelectedItem)=="Chuyến"?"Chuyen":"DangKy"; var list=new List<Choice>(); foreach(DataRow r in Db.Table(target).Rows) if(target=="Chuyen"||DuLichService.S(r,"Loai")=="Đoàn") list.Add(new Choice(r[0].ToString(),r[0]+" — "+r["TrangThai"])); combo.DataSource=list; };
    ((ComboBox)inputs["Loai"]).SelectedIndexChanged+=(s,e)=>sync(); sync(); if(row!=null) combo.SelectedValue=row["MaDoiTuong"].ToString();
   }
  }
  void Save() {
   try {
    var values=new Dictionary<string,object>();
    foreach(DataColumn c in Db.Table(table).Columns) {
     Control x=inputs[c.ColumnName]; object val;
     if(x is CheckBox) val=((CheckBox)x).Checked;
     else if(x is DateTimePicker) val=((DateTimePicker)x).Value.Date;
     else if(x is NumericUpDown) val=c.DataType==typeof(int)?(object)Decimal.ToInt32(((NumericUpDown)x).Value):((NumericUpDown)x).Value;
     else if(x is ComboBox) { var cb=(ComboBox)x; val=cb.DataSource!=null?Convert.ToString(cb.SelectedValue):Convert.ToString(cb.SelectedItem); }
     else val=x.Text.Trim(); values.Add(c.ColumnName,val);
    }
    DuLichService.SaveRow(table,id,values); DialogResult=DialogResult.OK; Close();
   } catch(Exception ex) { MessageBox.Show(ex.Message,"Kiểm tra dữ liệu",MessageBoxButtons.OK,MessageBoxIcon.Warning); }
  }
  static string[] Choices(string t,string c) {
   if(c=="Loai"&&t=="DangKy") return new[]{"Lẻ","Đoàn"};
   if(c=="Loai"&&t=="PhanCong") return new[]{"Chuyến","Đoàn"};
   if(c=="TrangThai"&&t=="DangKy") return new[]{"Nháp","Đã xác nhận","Hoàn tất","Đã hủy"};
   if(c=="TrangThai"&&t=="Chuyen") return new[]{"Dự kiến","Hoàn tất","Đã hủy"};
   if(c=="TrangThai"&&t=="KhaoSat") return new[]{"Đã lập","Đã gửi","Đã trả lời"};
   if(c=="LoaiThu") return new[]{"Đặt cọc","Tiền vé","Thanh toán đoàn"};
   if(c=="HinhThuc") return new[]{"Tiền mặt","Chuyển khoản","Thẻ"};
   if(c=="PhuongTien") return new[]{"Xe du lịch","Xe đò","Máy bay","Tàu hỏa","Tàu thủy","Đi bộ"};
   return null;
  }
  public class Choice { public string Key {get;set;} public string Label {get;set;} public Choice(string k,string l) {Key=k;Label=l;} }
 }
}
