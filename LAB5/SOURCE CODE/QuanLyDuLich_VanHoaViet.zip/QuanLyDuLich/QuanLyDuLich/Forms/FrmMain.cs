﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using QuanLyDuLich.Data;
using QuanLyDuLich.Services;
namespace QuanLyDuLich.Forms {
 public class FrmMain : Form {
  readonly ListBox navigation=new ListBox(); readonly DataGridView grid=new DataGridView();
  readonly TextBox search=new TextBox(); readonly Label title=new Label(); readonly Label note=new Label();
  readonly FlowLayoutPanel toolbar=new FlowLayoutPanel(); readonly NumericUpDown month=new NumericUpDown(),year=new NumericUpDown();
  string current="Tour"; DataTable report;
  public FrmMain() {
   Text="VĂN HÓA VIỆT • Quản lý công ty du lịch"; Size=new Size(1400,850); MinimumSize=new Size(1100,650); StartPosition=FormStartPosition.CenterScreen; Font=new Font("Segoe UI",10); BackColor=Color.White;
   var header=new Panel {Dock=DockStyle.Top,Height=85,BackColor=Color.FromArgb(16,65,89)};
   header.Controls.Add(new Label {Text="VĂN HÓA VIỆT  |  QUẢN LÝ CÔNG TY DU LỊCH",ForeColor=Color.White,Font=new Font("Segoe UI",18,FontStyle.Bold),AutoSize=true,Location=new Point(20,12)});
   header.Controls.Add(new Label {Text="TP.HCM   •   Mai Phước Sang — MSSV: 1250080159 — Lớp: 12_CNPM2",ForeColor=Color.LightCyan,AutoSize=true,Location=new Point(22,53)});
   navigation.Dock=DockStyle.Left; navigation.Width=265; navigation.BorderStyle=BorderStyle.None; navigation.BackColor=Color.FromArgb(233,242,247); navigation.ItemHeight=32; navigation.IntegralHeight=false;
   foreach(DataTable t in Db.Store.Tables) navigation.Items.Add(new FrmEditor.Choice(t.TableName,Db.Titles[t.TableName]));
   navigation.Items.Add(new FrmEditor.Choice("CongNo","15. Công nợ / mất cọc")); navigation.Items.Add(new FrmEditor.Choice("Luong","16. Lương hướng dẫn viên")); navigation.Items.Add(new FrmEditor.Choice("DoanhThu","17. Thực thu theo tháng")); navigation.DisplayMember="Label";
   var content=new Panel {Dock=DockStyle.Fill,Padding=new Padding(16)};
   title.Dock=DockStyle.Top; title.Height=38; title.Font=new Font("Segoe UI",16,FontStyle.Bold); title.ForeColor=Color.FromArgb(16,65,89);
   toolbar.Dock=DockStyle.Top; toolbar.Height=90; toolbar.WrapContents=true;
   note.Dock=DockStyle.Bottom; note.Height=85; note.ForeColor=Color.DimGray; note.Padding=new Padding(0,10,0,0);
   grid.Dock=DockStyle.Fill; grid.ReadOnly=true; grid.AllowUserToAddRows=false; grid.AllowUserToDeleteRows=false; grid.SelectionMode=DataGridViewSelectionMode.FullRowSelect; grid.MultiSelect=false; grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.DisplayedCells; grid.BackgroundColor=Color.White; grid.BorderStyle=BorderStyle.FixedSingle; grid.RowHeadersVisible=false; grid.AutoGenerateColumns=true; grid.AlternatingRowsDefaultCellStyle.BackColor=Color.FromArgb(244,249,252);
   content.Controls.Add(grid); content.Controls.Add(note); content.Controls.Add(toolbar); content.Controls.Add(title);
   Controls.Add(content); Controls.Add(navigation); Controls.Add(header);
   navigation.SelectedIndexChanged+=(s,e)=> { current=((FrmEditor.Choice)navigation.SelectedItem).Key; search.Text=""; LoadView(); };
   grid.CellDoubleClick+=(s,e)=> { if(e.RowIndex>=0&&Db.Titles.ContainsKey(current)) Edit(false); };
   navigation.SelectedIndex=0;
  }
  Button Button(string text,Action action) { var b=new Button {Text=text,AutoSize=true,Height=33,Padding=new Padding(7,0,7,0)}; b.Click+=(s,e)=>Run(action); toolbar.Controls.Add(b); return b; }
  void Run(Action a) { try { a(); } catch(Exception ex) {MessageBox.Show(this,ex.Message,"Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Warning);} }
  string Selected() { if(grid.CurrentRow==null) throw new InvalidOperationException("Hãy chọn một dòng dữ liệu."); return Convert.ToString(grid.CurrentRow.Cells[0].Value); }
  bool Ask(string message) { return MessageBox.Show(this,message,"Xác nhận thao tác",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes; }
  void Edit(bool add) {
   Run(()=> { string id=add?null:Selected(); if(id!=null) DuLichService.CheckEditable(current,DuLichService.Find(current,id),false); using(var f=new FrmEditor(current,id)) f.ShowDialog(this); RefreshGrid(); });
  }
  void LoadView() {
   toolbar.Controls.Clear(); title.Text=Db.Titles.ContainsKey(current)?Db.Titles[current]:current=="CongNo"?"Công nợ / tiền cọc bị mất":current=="Luong"?"Bảng lương hướng dẫn viên":"Thực thu theo tháng";
   if(Db.Titles.ContainsKey(current)) {
    Button("+ Thêm",()=>Edit(true)); Button("Sửa",()=>Edit(false)); Button("Xóa",()=> {string id=Selected(); if(Ask("Xóa dòng "+id+"? Dữ liệu được tham chiếu sẽ không thể xóa.")) {DuLichService.Delete(current,id); RefreshGrid();}});
    if(current=="DangKy") Button("Xác nhận đăng ký",()=> {DuLichService.Confirm(Selected()); RefreshGrid();});
    if(current=="DangKy"||current=="Chuyen") {
     Button("Hoàn tất",()=> {if(Ask("Ghi nhận chuyến / đoàn đã thực hiện xong?")) {DuLichService.Complete(current,Selected()); RefreshGrid();}});
     Button("Hủy",()=> {if(Ask("Hủy mục đang chọn? Đoàn hủy sẽ mất tiền cọc; phân công tương ứng được giải phóng.")) {DuLichService.Cancel(current,Selected()); RefreshGrid();}});
    }
    if(current=="Tour") Button("Xuất quảng cáo HTML",()=>SaveFile("Trang quảng cáo tour","HTML|*.html","Tours_VanHoaViet.html",BaoCaoService.Catalog));
    if(current=="ThuTien") Button("Xuất vé / phiếu thu",()=> {string id=Selected(); SaveFile("Xuất phiếu thu","HTML|*.html","PhieuThu_"+id+".html",path=>BaoCaoService.Receipt(id,path));});
    if(current=="KhaoSat") Button("Xuất phiếu khảo sát",()=> {string id=Selected(); SaveFile("Xuất phiếu khảo sát","HTML|*.html","KhaoSat_"+id+".html",path=>BaoCaoService.Survey(id,path));});
   } else if(current=="Luong"||current=="DoanhThu") {
    toolbar.Controls.Add(new Label {Text="Tháng / năm:",AutoSize=true,Padding=new Padding(0,8,0,0)});
    month.Minimum=1;month.Maximum=12;month.Value=DateTime.Today.Month;month.Width=60; year.Minimum=2000;year.Maximum=2200;year.Value=DateTime.Today.Year;year.Width=85; toolbar.Controls.Add(month);toolbar.Controls.Add(year);
   }
   Button("Làm mới",RefreshGrid); Button("Xuất CSV",()=>SaveFile("Xuất bảng đang xem","CSV|*.csv",current+".csv",path=> {var view=grid.DataSource as DataView; BaoCaoService.Csv(view!=null?view.ToTable():(DataTable)grid.DataSource,path);}));
   toolbar.Controls.Add(new Label {Text="Tìm:",AutoSize=true,Padding=new Padding(5,8,0,0)}); search.Width=210; toolbar.Controls.Add(search); search.TextChanged-=SearchChanged; search.TextChanged+=SearchChanged;
   note.Text=Hint(current); RefreshGrid();
  }
  void SearchChanged(object s,EventArgs e) { Run(ApplyFilter); }
  void ApplyFilter() {
   var view=grid.DataSource as DataView; if(view==null) return;
   string q=search.Text.Trim().Replace("'","''").Replace("[","[[]").Replace("%","[%]").Replace("*","[*]");
   view.RowFilter=q.Length==0?"":string.Join(" OR ",view.Table.Columns.Cast<DataColumn>().Where(c=>c.DataType==typeof(string)).Select(c=>"["+c.ColumnName+"] LIKE '%"+q+"%'"));
  }
  void RefreshGrid() {
   if(Db.Titles.ContainsKey(current)) grid.DataSource=new DataView(Db.Table(current));
   else {report=current=="CongNo"?BaoCaoService.Debt():current=="Luong"?BaoCaoService.Salary((int)month.Value,(int)year.Value):BaoCaoService.Revenue((int)month.Value,(int)year.Value); grid.DataSource=new DataView(report);}
   var table=((DataView)grid.DataSource).Table;
   foreach(DataGridViewColumn c in grid.Columns) {var d=table.Columns[c.DataPropertyName]; c.HeaderText=d.Caption; if(d.DataType==typeof(DateTime)) c.DefaultCellStyle.Format="dd/MM/yyyy"; if(d.DataType==typeof(decimal)) c.DefaultCellStyle.Format="N0";}
   ApplyFilter();
  }
  void SaveFile(string caption,string filter,string name,Action<string> write) { using(var d=new SaveFileDialog {Title=caption,Filter=filter,FileName=name,OverwritePrompt=true}) if(d.ShowDialog(this)==DialogResult.OK) {write(d.FileName); MessageBox.Show(this,"Đã xuất: "+d.FileName+"\nHTML: mở bằng trình duyệt, Ctrl+P để in.","Hoàn tất");} }
  static string Hint(string t) {
   switch(t) {
    case "DangKy": return "Quy trình: tạo nháp → danh sách bảo hiểm (nếu có) → thu tiền → xác nhận → phân công → hoàn tất.\nKhách lẻ 1–12 người theo chuyến; khách đoàn từ 13 người chọn ngày riêng. Giá chốt được lấy từ tour và lưu tại thời điểm đăng ký.";
    case "HanhTrinh": return "Nhập chặng liên tục từ 1, bắt đầu / kết thúc bằng đúng tên TP.HCM. Nơi đến chặng trước = nơi đi chặng sau.\nĐổi phương tiện tại nơi đến phải khớp chặng tiếp theo; khách sạn 2–5 sao. Không nghỉ: để tên trống, số sao = 0.";
    case "ThuTien": return "Khách lẻ thu đủ tiền vé trước xác nhận. Đoàn đặt cọc trước đi; thu phần còn lại sau hoàn tất. Phiếu thu đã lưu không sửa / xóa.\nChỉ ghi nhận thanh toán nội bộ, không tích hợp cổng thanh toán; phiếu thu không phải hóa đơn thuế.";
    case "PhanCong": return "Mỗi chuyến khách lẻ đúng 1 hướng dẫn viên; đoàn có thể nhiều người. Không trùng lịch kể cả ngày đầu / cuối.\nNhập lương tour thỏa thuận cho từng nhân viên; phân công hoàn tất được khóa.";
    case "KhaoSat": return "Tạo sau khi đăng ký hoàn tất; xuất HTML để in / tự gửi cho khách. Chương trình không tự gửi email.\nChọn Đã gửi sau khi thực sự gửi; Đã trả lời khi có góp ý và điểm 1–5.";
    case "Luong": return "Lương = lương cơ bản hiện tại + lương các phân công hoàn tất có ngày về trong tháng. Tour qua tháng tính vào tháng kết thúc.\nĐây là bảng tính, chưa có chức năng chốt / chi lương và lưu lịch sử mức lương cơ bản.";
    case "DoanhThu": return "Thống kê dòng tiền thực thu theo ngày thu, gồm cả tiền cọc; không phải doanh thu kế toán được ghi nhận.\nChọn tháng/năm rồi bấm Làm mới.";
    case "CongNo": return "Công nợ = giá trị đăng ký − đã thu. Đoàn đã hủy: không thu phần còn lại, tiền cọc chuyển sang cọc mất.\nĐề chưa nêu hoàn vé khách lẻ, vì vậy không cho hủy đăng ký lẻ đã thu tiền.";
    default: return "Nhập danh mục trước các bảng nghiệp vụ. Mã liên kết được chọn từ danh sách. Nhấp đúp để sửa.\nDữ liệu tự lưu trên máy sau mỗi thao tác; xem HUONG_DAN.md để biết quy trình, sao lưu và giới hạn.";
   }
  }
 }
}
