﻿using System;
using System.Threading;
using System.Windows.Forms;
using QuanLyDuLich.Data;
using QuanLyDuLich.Forms;
namespace QuanLyDuLich {
 static class Program {
  [STAThread] static void Main() {
   bool created;
   using(var mutex = new Mutex(true, "Local\\VanHoaViet_QuanLyDuLich", out created)) {
    if(!created) { MessageBox.Show("Ứng dụng đang mở. Hãy sử dụng cửa sổ hiện có."); return; }
    Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
    try { Db.Initialize(); Application.Run(new FrmMain()); }
    catch(Exception ex) { MessageBox.Show("Không thể mở ứng dụng: " + ex.Message, "Du lịch Văn Hóa Việt", MessageBoxButtons.OK, MessageBoxIcon.Error); }
   }
  }
 }
}
