﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
namespace QuanLyDuLich.Data {
 public static class Db {
  public static readonly DataSet Store = new DataSet("QuanLyDuLich");
  public static readonly Dictionary<string,string> Titles = new Dictionary<string,string>();
  public static string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VanHoaViet_QuanLyDuLich");
  public static string FilePath { get { return Path.Combine(Folder,"DuLieu.xml"); } }
  public static DataTable Table(string name) { return Store.Tables[name]; }
  static void Define(string name,string title,params string[] fields) {
   var t=Store.Tables.Add(name); Titles.Add(name,title);
   foreach(var f in fields) {
    var a=f.Split('|'); Type type=typeof(string);
    if(a[1]=="i") type=typeof(int); if(a[1]=="n") type=typeof(decimal); if(a[1]=="d") type=typeof(DateTime); if(a[1]=="b") type=typeof(bool);
    var c=t.Columns.Add(a[0],type); c.Caption=a[2]; c.AllowDBNull=false;
    c.DefaultValue=type==typeof(string)?(object)"":type==typeof(DateTime)?DateTime.Today:type==typeof(bool)?(object)false:type==typeof(decimal)?(object)0m:(object)0;
   }
   t.PrimaryKey=new[]{t.Columns[0]};
  }
  public static void Initialize() {
   if(Store.Tables.Count>0) return;
   Define("Tour","01. Tour du lịch","MaTour|s|Mã tour","TenTour|s|Tên tour","SoNgay|i|Số ngày","SoDem|i|Số đêm","DonGia|n|Đơn giá / khách (đ)","MoTa|s|Nội dung quảng cáo");
   Define("DiemThamQuan","02. Điểm tham quan","MaDiem|s|Mã điểm","TenDiem|s|Tên điểm tham quan","DiaDiem|s|Địa điểm","NoiDung|s|Nội dung","YNghia|s|Ý nghĩa");
   Define("HanhTrinh","03. Nơi dừng chân / chặng","MaChang|s|Mã chặng","MaTour|s|Tour","ThuTu|i|Thứ tự","NoiDi|s|Nơi đi","NoiDen|s|Nơi đến","PhuongTien|s|Phương tiện chặng","DoiPhuongTien|b|Đổi phương tiện tại nơi đến","CoAn|b|Có nơi ăn","NoiAn|s|Tên / địa chỉ nơi ăn","CoNghi|b|Có khách sạn","KhachSan|s|Tên khách sạn","SoSao|i|Hạng sao (0 nếu không nghỉ)");
   Define("TourDiem","04. Tham quan theo tour","MaCT|s|Mã chi tiết","MaTour|s|Tour","MaDiem|s|Điểm tham quan","ThuTu|i|Thứ tự tham quan");
   Define("DiemBanVe","05. Điểm bán vé","MaDiemBan|s|Mã điểm bán","TenDiemBan|s|Tên điểm bán","DiaChi|s|Địa chỉ","DienThoai|s|Điện thoại");
   Define("DiemDon","06. Điểm đón khách lẻ","MaDiemDon|s|Mã điểm đón","TenDiemDon|s|Tên điểm đón","DiaChi|s|Địa chỉ đón");
   Define("KhachHang","07. Khách hàng / chăm sóc","MaKH|s|Mã khách hàng","TenCoQuan|s|Tên cơ quan / đại diện gia đình","NguoiDaiDien|s|Họ tên / người đại diện","DiaChi|s|Địa chỉ liên hệ","DienThoai|s|Điện thoại","Email|s|Email","GhiChu|s|Ghi chú chăm sóc");
   Define("NhanVien","08. Hướng dẫn viên","MaNV|s|Mã nhân viên","HoTen|s|Họ tên","DienThoai|s|Điện thoại","LuongCoBan|n|Lương cơ bản (đ)");
   Define("Chuyen","09. Chuyến khách lẻ","MaChuyen|s|Mã chuyến","MaTour|s|Tour","NgayDi|d|Ngày đi","NgayVe|d|Ngày về","TrangThai|s|Trạng thái");
   Define("DangKy","10. Đăng ký du lịch","MaDK|s|Mã đăng ký","Loai|s|Loại khách","MaKH|s|Khách hàng","MaTour|s|Tour","MaChuyen|s|Chuyến (khách lẻ)","NgayDi|d|Ngày đi (đoàn)","NgayVe|d|Ngày về (đoàn)","SoNguoi|i|Số người","DonGia|n|Giá chốt / khách (đ)","BaoHiem|b|Mua bảo hiểm","DiaDiemDon|s|Địa điểm đón riêng (đoàn)","MaDiemDon|s|Điểm đón (khách lẻ)","MaDiemBan|s|Điểm bán vé (khách lẻ)","TrangThai|s|Trạng thái");
   Define("ThanhVien","11. Danh sách người đi","MaTV|s|Mã thành viên","MaDK|s|Đăng ký","HoTen|s|Họ tên","NgaySinh|d|Ngày sinh","GiayTo|s|Giấy tờ / thông tin định danh");
   Define("PhanCong","12. Phân công hướng dẫn","MaPC|s|Mã phân công","MaNV|s|Hướng dẫn viên","Loai|s|Loại phân công","MaDoiTuong|s|Mã chuyến / mã đăng ký đoàn","ThuLao|n|Lương tour thỏa thuận (đ)");
   Define("ThuTien","13. Thu tiền / đặt cọc","MaThu|s|Mã phiếu thu","MaDK|s|Đăng ký","NgayThu|d|Ngày thu","LoaiThu|s|Loại thu","SoTien|n|Số tiền (đ)","HinhThuc|s|Hình thức","GhiChu|s|Ghi chú");
   Define("KhaoSat","14. Khảo sát sau tour","MaKS|s|Mã khảo sát","MaDK|s|Đăng ký","NgayGui|d|Ngày gửi / lập phiếu","TrangThai|s|Trạng thái","Diem|i|Điểm hài lòng (1–5, chưa trả lời: 0)","GopY|s|Góp ý của khách");
   if(File.Exists(FilePath)) Store.ReadXml(FilePath,XmlReadMode.IgnoreSchema);
   Store.AcceptChanges();
  }
  public static void Save() {
   Directory.CreateDirectory(Folder); var tmp=FilePath+".tmp";
   try { Store.WriteXml(tmp,XmlWriteMode.WriteSchema); if(File.Exists(FilePath)) File.Replace(tmp,FilePath,FilePath+".bak"); else File.Move(tmp,FilePath); }
   finally { if(File.Exists(tmp)) File.Delete(tmp); }
   Store.AcceptChanges();
  }
 }
}
