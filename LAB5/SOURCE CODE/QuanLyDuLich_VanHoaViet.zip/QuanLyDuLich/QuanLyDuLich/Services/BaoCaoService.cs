﻿using System;
using System.Data;
using System.Linq;
using System.IO;
using System.Text;
using System.Net;
using QuanLyDuLich.Data;
namespace QuanLyDuLich.Services {
 public static class BaoCaoService {
  static string E(object x) { return WebUtility.HtmlEncode(Convert.ToString(x)); }
  public static DataTable Debt() {
   var t=new DataTable(); foreach(var s in new[]{"Mã đăng ký","Khách hàng","Loại","Trạng thái"}) t.Columns.Add(s);
   foreach(var s in new[]{"Giá trị đăng ký","Đã thu","Còn phải thu","Cọc mất khi hủy"}) t.Columns.Add(s,typeof(decimal));
   foreach(var r in DuLichService.Rows("DangKy")) {
    string id=DuLichService.S(r,"MaDK"); bool cancel=DuLichService.S(r,"TrangThai")=="Đã hủy";
    decimal paid=DuLichService.Paid(id); t.Rows.Add(id,DuLichService.Find("KhachHang",DuLichService.S(r,"MaKH"))["NguoiDaiDien"],r["Loai"],r["TrangThai"],DuLichService.Total(r),paid,cancel?0:DuLichService.Total(r)-paid,cancel?paid:0);
   } return t;
  }
  public static DataTable Salary(int month,int year) {
   var t=new DataTable(); t.Columns.Add("Mã NV"); t.Columns.Add("Họ tên"); t.Columns.Add("Lương cơ bản",typeof(decimal)); t.Columns.Add("Lương tour",typeof(decimal)); t.Columns.Add("Tổng lương",typeof(decimal)); t.Columns.Add("Số phân công hoàn tất",typeof(int));
   foreach(var nv in DuLichService.Rows("NhanVien")) {
    var pc=DuLichService.Rows("PhanCong").Where(r=>DuLichService.S(r,"MaNV")==DuLichService.S(nv,"MaNV")&&DuLichService.S(DuLichService.Target(r),"TrangThai")=="Hoàn tất"&&DuLichService.PcEnd(r).Month==month&&DuLichService.PcEnd(r).Year==year).ToArray();
    decimal extra=pc.Sum(r=>DuLichService.N(r,"ThuLao")), basic=DuLichService.N(nv,"LuongCoBan"); t.Rows.Add(nv["MaNV"],nv["HoTen"],basic,extra,basic+extra,pc.Length);
   } return t;
  }
  public static DataTable Revenue(int month,int year) {
   var t=new DataTable(); t.Columns.Add("Loại thu"); t.Columns.Add("Số phiếu",typeof(int)); t.Columns.Add("Thực thu trong tháng",typeof(decimal));
   foreach(string kind in new[]{"Đặt cọc","Tiền vé","Thanh toán đoàn"}) {
    var rows=DuLichService.Rows("ThuTien").Where(r=>DuLichService.S(r,"LoaiThu")==kind&&DuLichService.D(r,"NgayThu").Month==month&&DuLichService.D(r,"NgayThu").Year==year).ToArray(); t.Rows.Add(kind,rows.Length,rows.Sum(r=>DuLichService.N(r,"SoTien")));
   } return t;
  }
  public static void Csv(DataTable t,string path) {
   Func<object,string> q=x=> { string s=Convert.ToString(x); if(s.Length>0&&"=+-@\t\r".IndexOf(s[0])>=0) s="'"+s; return "\""+s.Replace("\"","\"\"")+"\""; };
   var b=new StringBuilder(); b.AppendLine(string.Join(";",t.Columns.Cast<DataColumn>().Select(c=>q(c.Caption)))); foreach(DataRow r in t.Rows) b.AppendLine(string.Join(";",r.ItemArray.Select(q))); File.WriteAllText(path,b.ToString(),new UTF8Encoding(true));
  }
  static string Page(string title,string body) { return "<!doctype html><html lang='vi'><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>"+E(title)+"</title><style>body{font:16px 'Segoe UI',sans-serif;max-width:1000px;margin:40px auto;padding:20px;color:#163149;background:#f3f7fa}article{background:white;padding:24px;margin:20px 0;border-radius:12px}h1,h2{color:#086b83}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccd8df;padding:9px;text-align:left}p{white-space:pre-wrap}@media print{body{background:white;margin:0}}</style><h1>"+E(title)+"</h1>"+body+"</html>"; }
  public static void Catalog(string path) {
   var b=new StringBuilder("<p>Công ty du lịch Văn Hóa Việt TP.HCM — Tất cả tour xuất phát và kết thúc tại TP.HCM.</p>");
   foreach(var r in DuLichService.Rows("Tour")) {
    string id=DuLichService.S(r,"MaTour"); DuLichService.CheckRoute(id);
    b.Append("<article><h2>"+E(r["TenTour"])+"</h2><p>Mã: "+E(id)+" · "+E(r["SoNgay"])+" ngày / "+E(r["SoDem"])+" đêm · "+DuLichService.N(r,"DonGia").ToString("N0")+" đồng / khách</p><p>"+E(r["MoTa"])+"</p><h3>Hành trình</h3><ol>");
    foreach(var c in DuLichService.Rows("HanhTrinh").Where(x=>DuLichService.S(x,"MaTour")==id).OrderBy(x=>DuLichService.I(x,"ThuTu"))) b.Append("<li>"+E(c["NoiDi"])+" → "+E(c["NoiDen"])+" — "+E(c["PhuongTien"])+(DuLichService.B(c,"CoAn")?"; ăn tại "+E(c["NoiAn"]):"")+(DuLichService.B(c,"CoNghi")?"; khách sạn "+E(c["KhachSan"])+" ("+E(c["SoSao"])+" sao)":"")+"</li>");
    b.Append("</ol><h3>Điểm tham quan</h3>");
    foreach(var ct in DuLichService.Rows("TourDiem").Where(x=>DuLichService.S(x,"MaTour")==id).OrderBy(x=>DuLichService.I(x,"ThuTu"))) {var d=DuLichService.Find("DiemThamQuan",DuLichService.S(ct,"MaDiem")); b.Append("<h4>"+E(d["TenDiem"])+" — "+E(d["DiaDiem"])+"</h4><p>"+E(d["NoiDung"])+"\nÝ nghĩa: "+E(d["YNghia"])+"</p>");}
    b.Append("<h3>Lịch khởi hành khách lẻ</h3><ul>");
    foreach(var c in DuLichService.Rows("Chuyen").Where(x=>DuLichService.S(x,"MaTour")==id&&DuLichService.S(x,"TrangThai")=="Dự kiến"&&DuLichService.D(x,"NgayDi")>=DateTime.Today)) b.Append("<li>"+E(c["MaChuyen"])+": "+DuLichService.D(c,"NgayDi").ToString("dd/MM/yyyy")+" – "+DuLichService.D(c,"NgayVe").ToString("dd/MM/yyyy")+"</li>"); b.Append("</ul></article>");
   }
   if(!DuLichService.Rows("Tour").Any()) b.Append("<p>Chưa có tour được công bố.</p>"); File.WriteAllText(path,Page("Du lịch Văn Hóa Việt",b.ToString()),Encoding.UTF8);
  }
  public static void Survey(string id,string path) {
   var r=DuLichService.Find("KhaoSat",id); var dk=DuLichService.Find("DangKy",DuLichService.S(r,"MaDK")); var kh=DuLichService.Find("KhachHang",DuLichService.S(dk,"MaKH"));
   File.WriteAllText(path,Page("Phiếu khảo sát sau tour","<article><p>Mã phiếu: "+E(id)+"\nKhách hàng: "+E(kh["NguoiDaiDien"])+"\nĐăng ký: "+E(dk["MaDK"])+"\nTour: "+E(DuLichService.Find("Tour",DuLichService.S(dk,"MaTour"))["TenTour"])+"</p><p>Mức độ hài lòng (khoanh 1–5): 1  2  3  4  5\n1: Rất không hài lòng; 5: Rất hài lòng.</p><p>Điểm đã ghi nhận: "+E(r["Diem"])+"\nGóp ý: "+E(r["GopY"])+"</p><p>........................................................................................\n........................................................................................</p><p>Xin cảm ơn quý khách!</p></article>"),Encoding.UTF8);
  }
  public static void Receipt(string id,string path) {
   var r=DuLichService.Find("ThuTien",id); var dk=DuLichService.Find("DangKy",DuLichService.S(r,"MaDK")); var kh=DuLichService.Find("KhachHang",DuLichService.S(dk,"MaKH"));
   File.WriteAllText(path,Page(DuLichService.S(r,"LoaiThu")=="Tiền vé"?"Vé du lịch / Phiếu thu":"Phiếu thu du lịch","<article><p>Mã phiếu: "+E(id)+"\nNgày thu: "+DuLichService.D(r,"NgayThu").ToString("dd/MM/yyyy")+"\nKhách hàng: "+E(kh["NguoiDaiDien"])+"\nĐăng ký: "+E(dk["MaDK"])+"\nTour: "+E(DuLichService.Find("Tour",DuLichService.S(dk,"MaTour"))["TenTour"])+"\nSố người: "+E(dk["SoNguoi"])+"\nNgày đi: "+DuLichService.Start(dk).ToString("dd/MM/yyyy")+"\nNgày về: "+DuLichService.End(dk).ToString("dd/MM/yyyy")+"\nNội dung thu: "+E(r["LoaiThu"])+"\nSố tiền: "+DuLichService.N(r,"SoTien").ToString("N0")+" đồng\nHình thức: "+E(r["HinhThuc"])+"</p><p>Đây là phiếu thu nội bộ, không phải hóa đơn thuế.</p></article>"),Encoding.UTF8);
  }
 }
}
