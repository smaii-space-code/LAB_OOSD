﻿using System;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using QuanLyDuLich.Data;
namespace QuanLyDuLich.Services {
 public static class DuLichService {
  public static IEnumerable<DataRow> Rows(string table) { return Db.Table(table).AsEnumerable(); }
  public static string S(DataRow r,string c) { return Convert.ToString(r[c]); }
  public static int I(DataRow r,string c) { return Convert.ToInt32(r[c]); }
  public static decimal N(DataRow r,string c) { return Convert.ToDecimal(r[c]); }
  public static DateTime D(DataRow r,string c) { return Convert.ToDateTime(r[c]).Date; }
  public static bool B(DataRow r,string c) { return Convert.ToBoolean(r[c]); }
  public static void Require(bool value,string message) { if(!value) throw new InvalidOperationException(message); }
  public static DataRow Find(string table,string id) { var r=Db.Table(table).Rows.Find(id); Require(r!=null,"Không tìm thấy " + Db.Titles[table] + ": " + id); return r; }
  public static string Id(string table) { return table.Substring(0,Math.Min(3,table.Length)).ToUpperInvariant()+Guid.NewGuid().ToString("N").Substring(0,8).ToUpperInvariant(); }
  public static void Commit(Action action) {
   var backup=Db.Store.Copy();
   try { action(); Validate(); Db.Save(); }
   catch { Db.Store.Clear(); Db.Store.Merge(backup,false,MissingSchemaAction.Ignore); Db.Store.AcceptChanges(); throw; }
  }
  public static decimal Total(DataRow r) { return I(r,"SoNguoi")*N(r,"DonGia"); }
  public static decimal Paid(string id) { return Rows("ThuTien").Where(r=>S(r,"MaDK")==id).Sum(r=>N(r,"SoTien")); }
  public static DateTime Start(DataRow r) { return S(r,"Loai")=="Lẻ"?D(Find("Chuyen",S(r,"MaChuyen")),"NgayDi"):D(r,"NgayDi"); }
  public static DateTime End(DataRow r) { return S(r,"Loai")=="Lẻ"?D(Find("Chuyen",S(r,"MaChuyen")),"NgayVe"):D(r,"NgayVe"); }
  public static DataRow Target(DataRow pc) { return Find(S(pc,"Loai")=="Chuyến"?"Chuyen":"DangKy",S(pc,"MaDoiTuong")); }
  public static DateTime PcStart(DataRow pc) { var r=Target(pc); return S(pc,"Loai")=="Chuyến"?D(r,"NgayDi"):Start(r); }
  public static DateTime PcEnd(DataRow pc) { var r=Target(pc); return S(pc,"Loai")=="Chuyến"?D(r,"NgayVe"):End(r); }
  public static IEnumerable<DataRow> Assignments(string type,string id) { return Rows("PhanCong").Where(r=>S(r,"Loai")==type&&S(r,"MaDoiTuong")==id); }
  public static void Required(DataRow r,params string[] columns) { foreach(var c in columns) Require(!string.IsNullOrWhiteSpace(S(r,c)),r.Table.Columns[c].Caption+" không được trống."); }
  static void OneOf(DataRow r,string c,params string[] values) { Require(values.Contains(S(r,c)),"Giá trị không hợp lệ: "+r.Table.Columns[c].Caption); }
  static void Ref(DataRow r,string c,string table) { Find(table,S(r,c)); }
  static void Period(DataRow r,string tour) {
   var t=Find("Tour",tour); Require(D(r,"NgayVe")>=D(r,"NgayDi"),"Ngày về không được trước ngày đi.");
   Require((D(r,"NgayVe")-D(r,"NgayDi")).Days+1==I(t,"SoNgay"),"Khoảng ngày đi–về phải đúng số ngày của tour.");
  }
  public static void Validate() {
   foreach(DataTable t in Db.Store.Tables) foreach(DataRow r in t.Rows) Required(r,t.Columns[0].ColumnName);
   foreach(var r in Rows("Tour")) { Required(r,"TenTour"); Require(I(r,"SoNgay")>0&&I(r,"SoDem")>=0&&I(r,"SoDem")<=I(r,"SoNgay"),"Số ngày / đêm của tour không hợp lệ."); Require(N(r,"DonGia")>0,"Giá tour phải lớn hơn 0."); }
   foreach(var r in Rows("DiemThamQuan")) Required(r,"TenDiem","DiaDiem","NoiDung","YNghia");
   foreach(var r in Rows("DiemBanVe")) Required(r,"TenDiemBan","DiaChi","DienThoai");
   foreach(var r in Rows("DiemDon")) Required(r,"TenDiemDon","DiaChi");
   foreach(var r in Rows("KhachHang")) Required(r,"NguoiDaiDien","DiaChi","DienThoai");
   foreach(var r in Rows("NhanVien")) { Required(r,"HoTen","DienThoai"); Require(N(r,"LuongCoBan")>=0,"Lương cơ bản không được âm."); }
   foreach(var r in Rows("HanhTrinh")) {
    Ref(r,"MaTour","Tour"); Required(r,"NoiDi","NoiDen","PhuongTien"); Require(I(r,"ThuTu")>0,"Thứ tự phải dương.");
    Require(Rows("HanhTrinh").Count(x=>S(x,"MaTour")==S(r,"MaTour")&&I(x,"ThuTu")==I(r,"ThuTu"))==1,"Trùng thứ tự chặng của tour.");
    if(B(r,"CoAn")) Required(r,"NoiAn");
    if(B(r,"CoNghi")) { Required(r,"KhachSan"); Require(I(r,"SoSao")>=2&&I(r,"SoSao")<=5,"Khách sạn phải từ 2 đến 5 sao."); }
    else Require(I(r,"SoSao")==0&&S(r,"KhachSan")=="","Không nghỉ khách sạn: để trống tên và đặt số sao = 0.");
   }
   foreach(var r in Rows("TourDiem")) {
    Ref(r,"MaTour","Tour"); Ref(r,"MaDiem","DiemThamQuan"); Require(I(r,"ThuTu")>0,"Thứ tự tham quan phải dương.");
    Require(Rows("TourDiem").Count(x=>S(x,"MaTour")==S(r,"MaTour")&&(S(x,"MaDiem")==S(r,"MaDiem")||I(x,"ThuTu")==I(r,"ThuTu")))==1,"Trùng điểm / thứ tự tham quan trong tour.");
   }
   foreach(var r in Rows("Chuyen")) { Ref(r,"MaTour","Tour"); Period(r,S(r,"MaTour")); OneOf(r,"TrangThai","Dự kiến","Hoàn tất","Đã hủy"); }
   foreach(var r in Rows("DangKy")) {
    Ref(r,"MaKH","KhachHang"); Ref(r,"MaTour","Tour"); OneOf(r,"Loai","Lẻ","Đoàn"); OneOf(r,"TrangThai","Nháp","Đã xác nhận","Hoàn tất","Đã hủy");
    Require(N(r,"DonGia")>0,"Giá chốt phải lớn hơn 0.");
    if(S(r,"Loai")=="Lẻ") {
     Require(I(r,"SoNguoi")>=1&&I(r,"SoNguoi")<=12,"Khách lẻ: từ 1 đến 12 người (quy ước trường hợp 12).");
     var c=Find("Chuyen",S(r,"MaChuyen")); Require(S(c,"MaTour")==S(r,"MaTour"),"Chuyến không thuộc tour đã chọn.");
     Require(D(r,"NgayDi")==D(c,"NgayDi")&&D(r,"NgayVe")==D(c,"NgayVe"),"Ngày khách lẻ phải theo lịch chuyến.");
     Ref(r,"MaDiemDon","DiemDon"); Ref(r,"MaDiemBan","DiemBanVe");
     Require(S(c,"TrangThai")!="Đã hủy"||S(r,"TrangThai")=="Đã hủy","Chuyến đã hủy không nhận đăng ký.");
    } else {
     Require(I(r,"SoNguoi")>12,"Khách đoàn phải trên 12 người."); Required(r,"DiaDiemDon");
     Required(Find("KhachHang",S(r,"MaKH")),"TenCoQuan");
     Require(S(r,"MaChuyen")==""&&S(r,"MaDiemBan")==""&&S(r,"MaDiemDon")=="","Khách đoàn không chọn chuyến / điểm bán / điểm đón khách lẻ."); Period(r,S(r,"MaTour"));
    }
    Require(Paid(S(r,"MaDK"))<=Total(r),"Tổng tiền thu vượt giá trị đăng ký.");
    if(S(r,"TrangThai")=="Đã xác nhận"||S(r,"TrangThai")=="Hoàn tất") CheckConfirm(r);
   }
   foreach(var r in Rows("ThanhVien")) {
    var dk=Find("DangKy",S(r,"MaDK")); Required(r,"HoTen","GiayTo"); Require(D(r,"NgaySinh")<=DateTime.Today,"Ngày sinh không hợp lệ.");
    Require(Rows("ThanhVien").Count(x=>S(x,"MaDK")==S(r,"MaDK"))<=I(dk,"SoNguoi"),"Danh sách vượt số người đăng ký.");
    Require(Rows("ThanhVien").Count(x=>S(x,"MaDK")==S(r,"MaDK")&&S(x,"GiayTo")==S(r,"GiayTo"))==1,"Trùng giấy tờ trong cùng đăng ký.");
   }
   foreach(var r in Rows("PhanCong")) {
    Ref(r,"MaNV","NhanVien"); OneOf(r,"Loai","Chuyến","Đoàn"); var target=Target(r);
    if(S(r,"Loai")=="Đoàn") Require(S(target,"Loai")=="Đoàn","Chỉ phân công trực tiếp cho đăng ký đoàn.");
    Require(S(target,"TrangThai")!="Đã hủy","Không phân công cho chuyến / đoàn đã hủy.");
    Require(N(r,"ThuLao")>=0,"Lương tour không được âm.");
    if(S(r,"Loai")=="Chuyến") Require(Assignments("Chuyến",S(r,"MaDoiTuong")).Count()==1,"Mỗi chuyến khách lẻ chỉ có một hướng dẫn viên.");
    Require(!Rows("PhanCong").Any(x=>x!=r&&S(x,"MaNV")==S(r,"MaNV")&&PcStart(x)<=PcEnd(r)&&PcEnd(x)>=PcStart(r)),"Lịch hướng dẫn viên bị chồng chéo (tính cả ngày đi và ngày về).");
   }
   foreach(var r in Rows("ThuTien")) {
    var dk=Find("DangKy",S(r,"MaDK")); Require(N(r,"SoTien")>0,"Số tiền thu phải dương."); Required(r,"HinhThuc"); OneOf(r,"LoaiThu","Đặt cọc","Tiền vé","Thanh toán đoàn");
    Require(D(r,"NgayThu")<=DateTime.Today,"Ngày thu không được ở tương lai.");
    if(S(dk,"Loai")=="Lẻ") Require(S(r,"LoaiThu")=="Tiền vé","Khách lẻ thanh toán tiền vé.");
    else {
     Require(S(r,"LoaiThu")!="Tiền vé","Khách đoàn dùng đặt cọc hoặc thanh toán đoàn.");
     if(S(r,"LoaiThu")=="Đặt cọc") Require(D(r,"NgayThu")<=Start(dk),"Đặt cọc phải trước hoặc trong ngày đi.");
     if(S(r,"LoaiThu")=="Thanh toán đoàn") Require(S(dk,"TrangThai")=="Hoàn tất"&&D(r,"NgayThu")>=End(dk),"Chỉ thanh toán đoàn sau khi kết thúc chuyến.");
    }
   }
   foreach(var r in Rows("KhaoSat")) {
    var dk=Find("DangKy",S(r,"MaDK")); Require(S(dk,"TrangThai")=="Hoàn tất","Chỉ khảo sát đăng ký đã hoàn tất.");
    Require(D(r,"NgayGui")>=End(dk)&&D(r,"NgayGui")<=DateTime.Today,"Ngày khảo sát phải sau tour và không ở tương lai.");
    OneOf(r,"TrangThai","Đã lập","Đã gửi","Đã trả lời");
    Require(S(r,"TrangThai")=="Đã trả lời"?I(r,"Diem")>=1&&I(r,"Diem")<=5:I(r,"Diem")==0,"Điểm khảo sát: 1–5 khi đã trả lời, còn lại bằng 0.");
    Require(Rows("KhaoSat").Count(x=>S(x,"MaDK")==S(r,"MaDK"))==1,"Mỗi đăng ký có một phiếu khảo sát tổng hợp.");
   }
  }
  public static void CheckRoute(string tour) {
   var a=Rows("HanhTrinh").Where(x=>S(x,"MaTour")==tour).OrderBy(x=>I(x,"ThuTu")).ToArray();
   Require(a.Length>0,"Cần khai báo hành trình trước khi xác nhận / quảng cáo tour.");
   Require(S(a[0],"NoiDi")=="TP.HCM"&&S(a[a.Length-1],"NoiDen")=="TP.HCM","Hành trình phải bắt đầu và kết thúc tại TP.HCM (nhập đúng tên này).");
   for(int i=0;i<a.Length;i++) {
    Require(I(a[i],"ThuTu")==i+1,"Thứ tự chặng phải liên tục từ 1.");
    if(i<a.Length-1) {
     Require(S(a[i],"NoiDen")==S(a[i+1],"NoiDi"),"Nơi đến của chặng trước phải là nơi đi của chặng sau.");
     Require(B(a[i],"DoiPhuongTien")==(S(a[i],"PhuongTien")!=S(a[i+1],"PhuongTien")),"Cờ đổi phương tiện phải khớp phương tiện của chặng tiếp theo.");
    } else Require(!B(a[i],"DoiPhuongTien"),"Chặng cuối về TP.HCM không đổi phương tiện đi tiếp.");
   }
   Require(Rows("TourDiem").Any(x=>S(x,"MaTour")==tour),"Tour cần ít nhất một điểm tham quan.");
  }
  static void CheckConfirm(DataRow r) {
   CheckRoute(S(r,"MaTour"));
   if(B(r,"BaoHiem")) Require(Rows("ThanhVien").Count(x=>S(x,"MaDK")==S(r,"MaDK"))==I(r,"SoNguoi"),"Mua bảo hiểm: cần danh sách đủ tất cả người đi.");
   if(S(r,"Loai")=="Lẻ") Require(Paid(S(r,"MaDK"))==Total(r),"Khách lẻ phải thanh toán đủ tiền vé trước xác nhận.");
   else Require(Rows("ThuTien").Any(x=>S(x,"MaDK")==S(r,"MaDK")&&S(x,"LoaiThu")=="Đặt cọc"&&N(x,"SoTien")>0),"Khách đoàn phải đặt cọc trước xác nhận.");
  }
  public static void Confirm(string id) { Commit(()=> { var r=Find("DangKy",id); Require(S(r,"TrangThai")=="Nháp","Chỉ xác nhận đăng ký nháp."); Require(Start(r)>=DateTime.Today,"Không xác nhận đăng ký đã qua ngày đi."); r["TrangThai"]="Đã xác nhận"; }); }
  public static void Cancel(string table,string id) { Commit(()=> {
   var r=Find(table,id); Require(S(r,"TrangThai")!="Hoàn tất"&&S(r,"TrangThai")!="Đã hủy","Không thể hủy mục này.");
   if(table=="Chuyen") {
    Require(!Rows("DangKy").Any(x=>S(x,"MaChuyen")==id&&S(x,"TrangThai")!="Đã hủy"),"Hủy các đăng ký thuộc chuyến trước.");
    RemoveAssignments("Chuyến",id);
   } else {
    Require(S(r,"Loai")=="Đoàn"||Paid(id)==0,"Khách lẻ đã trả tiền: đề chưa quy định hoàn vé, không tự hủy. Cần bổ sung chính sách hoàn vé.");
    if(S(r,"Loai")=="Đoàn") RemoveAssignments("Đoàn",id);
   }
   r["TrangThai"]="Đã hủy";
  }); }
  static void RemoveAssignments(string type,string id) { foreach(var x in Assignments(type,id).ToArray()) Db.Table("PhanCong").Rows.Remove(x); }
  public static void Complete(string table,string id) { Commit(()=> {
   var r=Find(table,id); Require(S(r,"TrangThai")!="Đã hủy"&&S(r,"TrangThai")!="Hoàn tất","Trạng thái không phù hợp.");
   if(table=="Chuyen") {
    Require(DateTime.Today>=D(r,"NgayVe"),"Chưa đến ngày về."); Require(Assignments("Chuyến",id).Count()==1,"Chuyến cần đúng một hướng dẫn viên.");
    var bookings=Rows("DangKy").Where(x=>S(x,"MaChuyen")==id&&S(x,"TrangThai")!="Đã hủy").ToArray();
    Require(bookings.Length>0&&bookings.All(x=>S(x,"TrangThai")=="Đã xác nhận"),"Chuyến phải có khách và tất cả đăng ký còn hiệu lực đã xác nhận.");
    foreach(var b in bookings) b["TrangThai"]="Hoàn tất";
   } else {
    Require(S(r,"Loai")=="Đoàn","Hoàn tất khách lẻ tại màn hình Chuyến.");
    Require(S(r,"TrangThai")=="Đã xác nhận"&&DateTime.Today>=End(r),"Đoàn phải được xác nhận và đã đến ngày về.");
    Require(Assignments("Đoàn",id).Any(),"Đoàn cần ít nhất một hướng dẫn viên.");
   }
   r["TrangThai"]="Hoàn tất";
  }); }
  // Central edit guards: all dialogs and tests use this path.
  public static void CheckEditable(string table,DataRow r,bool delete) {
   if(r==null) return;
   if(table=="ThuTien") throw new InvalidOperationException("Phiếu thu đã lưu không được sửa / xóa để giữ lịch sử thu tiền.");
   if(table=="DangKy") Require(S(r,"TrangThai")=="Nháp"&&Paid(S(r,"MaDK"))==0,"Đăng ký đã thu tiền / xác nhận được khóa. Không sửa giá hoặc thông tin chuyến.");
   if(table=="Chuyen") Require(S(r,"TrangThai")=="Dự kiến"&&!Rows("DangKy").Any(x=>S(x,"MaChuyen")==S(r,"MaChuyen")),"Chuyến có đăng ký hoặc đã đóng được khóa.");
   if(table=="ThanhVien") Require(S(Find("DangKy",S(r,"MaDK")),"TrangThai")=="Nháp","Danh sách đã xác nhận được khóa.");
   if(table=="PhanCong") Require(S(Target(r),"TrangThai")!="Hoàn tất","Phân công đã hoàn tất được khóa để giữ lương tour.");
   if(table=="Tour"||table=="HanhTrinh"||table=="TourDiem") {
    string tour=S(r,"MaTour");
    Require(!Rows("DangKy").Any(x=>S(x,"MaTour")==tour&&(Paid(S(x,"MaDK"))>0||S(x,"TrangThai")!="Nháp")),"Tour đã được sử dụng / thu tiền: giữ nguyên hành trình và thông tin; tạo tour mới để thay đổi.");
   }
  }
  public static void SaveRow(string table,string id,Dictionary<string,object> values) { Commit(()=> {
   var t=Db.Table(table); var r=id==null?null:Find(table,id); CheckEditable(table,r,false);
   if(r==null) { r=t.NewRow(); foreach(var kv in values) r[kv.Key]=kv.Value; t.Rows.Add(r); }
   else foreach(var kv in values) r[kv.Key]=kv.Value;
   if(table=="DangKy") {
    Require(S(r,"TrangThai")=="Nháp","Tạo / sửa đăng ký với trạng thái Nháp.");
    if(S(r,"Loai")=="Lẻ") { var c=Find("Chuyen",S(r,"MaChuyen")); Require(S(c,"TrangThai")=="Dự kiến","Chuyến không còn nhận đăng ký."); r["NgayDi"]=c["NgayDi"]; r["NgayVe"]=c["NgayVe"]; }
   }
   if(table=="Chuyen") Require(S(r,"TrangThai")=="Dự kiến","Tạo chuyến với trạng thái Dự kiến.");
   if(table=="ThuTien") {
    var dk=Find("DangKy",S(r,"MaDK")); Require(S(dk,"TrangThai")!="Đã hủy","Đăng ký đã hủy không thu thêm.");
    if(S(r,"LoaiThu")=="Đặt cọc"||S(r,"LoaiThu")=="Tiền vé") Require(S(dk,"TrangThai")=="Nháp","Thu cọc / tiền vé khi đăng ký còn nháp.");
   }
   if(table=="ThanhVien") Require(S(Find("DangKy",S(r,"MaDK")),"TrangThai")=="Nháp","Chỉ thêm người khi đăng ký còn nháp.");
   if(table=="PhanCong") Require(S(Target(r),"TrangThai")!="Hoàn tất","Không thêm phân công vào tour đã hoàn tất.");
   if(table=="HanhTrinh"||table=="TourDiem") CheckEditable(table,r,false);
  }); }
  public static void Delete(string table,string id) { Commit(()=> { var r=Find(table,id); CheckEditable(table,r,true); Db.Table(table).Rows.Remove(r); }); }
 }
}
